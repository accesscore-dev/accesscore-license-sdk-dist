"""The issuing side, as Python calls it.

Only an issuer holds a private key, and only an issuer calls this. A deployment that verifies
tokens has the module installed and nothing to do with it: signing needs a key a customer never
holds, so its presence grants nothing.
"""

from __future__ import annotations

from typing import Any, Sequence

from ._core import AclicCore, core as shared_core

__all__ = ["LicenseIssuer", "ProductKeys", "ReleaseVersions"]


class LicenseIssuer:
    """Turns a decision the ledger already made into signed bytes."""

    def __init__(self, core: AclicCore | None = None) -> None:
        self._core = core or shared_core()

    def sign(self, payload: dict[str, Any], private_key_pem: str) -> dict[str, Any]:
        """Sign a payload into a license token.

        The key is handed over as PKCS#8 and wiped from the core's memory as soon as the
        signature exists. Whatever copy the caller holds is the caller's to clear.
        """
        return self._core.sign({"payload": payload, "privateKey": private_key_pem})

    def fingerprint_of(self, private_key_pem: str) -> str:
        """The fingerprint of the key pair a signing key belongs to.

        What a deployment compares against the public key compiled into its own binary. Two
        different values mean every license issued here would be refused there as unverifiable.
        """
        return self._core.sign({"privateKey": private_key_pem})["fingerprint"]

    def verify(self, token: str, keys: Sequence[dict[str, str]]) -> dict[str, Any]:
        """Check a token's signature without judging anything else about it."""
        return self._core.verify_signature({"token": token, "keys": list(keys)})

    def read_payload(self, token: str) -> dict[str, Any] | None:
        """Read what a token grants, without checking its signature."""
        return self.verify(token, []).get("payload")

    def generate_keypair(self, algorithm: str = "Ed25519") -> dict[str, Any]:
        """Generate a signing key pair."""
        return self._core.generate_keypair({"algorithm": algorithm})


class ProductKeys:
    """The customer-facing key an operator types to activate a deployment.

    Both halves of licensing need this and they have to agree, so every operation crosses to the
    core rather than being written a second time in Python.
    """

    def __init__(self, core: AclicCore | None = None) -> None:
        self._core = core or shared_core()

    def generate(self, prefix: str) -> str:
        """A fresh key, grouped and checksummed."""
        return self._core.product_key({"operation": "GENERATE", "prefix": prefix})["key"]

    def is_valid(self, prefix: str, candidate: str) -> bool:
        """Whether a key as typed is well formed and its checksum matches."""
        return bool(
            self._core.product_key(
                {"operation": "VALIDATE", "prefix": prefix, "key": candidate or ""}
            )["valid"]
        )

    def canonical(self, prefix: str, candidate: str) -> str | None:
        """The canonical grouped form, or None when the value is not well formed."""
        return self._core.product_key(
            {"operation": "CANONICAL", "prefix": prefix, "key": candidate or ""}
        )["key"]

    def masked(self, prefix: str, candidate: str) -> str | None:
        """The key rendered for display: its two ends, with the middle withheld."""
        return self._core.product_key(
            {"operation": "MASK", "prefix": prefix, "key": candidate or ""}
        )["key"]


class ReleaseVersions:
    """How a release version is ranked, for both sides of a license."""

    def __init__(self, core: AclicCore | None = None) -> None:
        self._core = core or shared_core()

    def compare(self, left: str, right: str) -> int:
        """Rank two versions: negative, zero, or positive."""
        return int(
            self._core.release(
                {"operation": "COMPARE", "version": left or "", "other": right or ""}
            )["result"]
        )

    def is_within_ceiling(self, release: str, ceiling: str | None) -> bool:
        """Whether a release is allowed by a ceiling."""
        return bool(
            self._core.release(
                {"operation": "WITHIN_CEILING", "version": release or "", "other": ceiling}
            )["result"]
        )

    def sort_key(self, version: str) -> str:
        """The normalized form a list of releases is ordered by."""
        return str(
            self._core.release({"operation": "SORT_KEY", "version": version or ""})["result"]
        )
