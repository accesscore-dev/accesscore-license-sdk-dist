"""Framework adapters.

An adapter calls the neutral gate and moves what it answered into that framework's response. It
holds no judgement of its own — not the status code, not the error code, not the message. That
is why adding a framework stays cheap, and why every framework refuses the same request the
same way.

Each adapter imports its framework lazily, so a product pays only for the one it uses.
"""

from __future__ import annotations

import json
from typing import Any, Callable, Iterable, Sequence

from .gate import Gate, LicenseDenied

__all__ = [
    "asgi_license_gate",
    "django_license_middleware",
    "fastapi_license_dependency",
    "fastapi_register_exception_handler",
    "flask_register",
    "path_is_open",
    "wsgi_license_gate",
]


def path_is_open(path: str, open_prefixes: Sequence[str]) -> bool:
    """Whether a path stays reachable while the deployment is unlicensed.

    Which paths those are is the product's decision: a deployment has to reach its own license
    screen and its own activation endpoints in order to stop being unlicensed, and only the
    product knows where they live.
    """
    return any(path.startswith(prefix) for prefix in open_prefixes)


def _denial_response_parts(denied: LicenseDenied) -> tuple[int, bytes]:
    """The status and body every adapter answers a refusal with."""
    return denied.http_status, json.dumps(denied.body()).encode("utf-8")


# -- FastAPI -----------------------------------------------------------------------------


def fastapi_license_dependency(gate: Gate, feature: str | None = None) -> Callable[[], None]:
    """A dependency that refuses a request the license does not cover.

    Used without a feature it checks that the deployment may serve at all; with one it checks
    that the license grants that feature.
    """

    def dependency() -> None:
        if feature is None:
            gate.require_usable()
        else:
            gate.require_feature(feature)

    return dependency


def fastapi_register_exception_handler(app: Any) -> None:
    """Turn a gate refusal into a FastAPI response, application-wide."""
    from fastapi.responses import JSONResponse

    @app.exception_handler(LicenseDenied)
    async def _handle(_request: Any, denied: LicenseDenied) -> Any:
        return JSONResponse(status_code=denied.http_status, content=denied.body())


# -- ASGI --------------------------------------------------------------------------------


def asgi_license_gate(app: Any, gate: Gate, open_prefixes: Sequence[str] = ()) -> Any:
    """Close an ASGI application while its license does not let it serve."""

    async def middleware(scope: dict, receive: Any, send: Any) -> None:
        if scope.get("type") != "http" or path_is_open(scope.get("path", ""), open_prefixes):
            await app(scope, receive, send)
            return

        try:
            gate.require_usable()
        except LicenseDenied as denied:
            status, body = _denial_response_parts(denied)
            await send(
                {
                    "type": "http.response.start",
                    "status": status,
                    "headers": [(b"content-type", b"application/json")],
                }
            )
            await send({"type": "http.response.body", "body": body})
            return

        await app(scope, receive, send)

    return middleware


# -- WSGI --------------------------------------------------------------------------------


def wsgi_license_gate(app: Any, gate: Gate, open_prefixes: Sequence[str] = ()) -> Any:
    """Close a WSGI application while its license does not let it serve."""

    def middleware(environ: dict, start_response: Any) -> Iterable[bytes]:
        if path_is_open(environ.get("PATH_INFO", ""), open_prefixes):
            return app(environ, start_response)

        try:
            gate.require_usable()
        except LicenseDenied as denied:
            status, body = _denial_response_parts(denied)
            start_response(
                f"{status} Forbidden",
                [
                    ("Content-Type", "application/json"),
                    ("Content-Length", str(len(body))),
                ],
            )
            return [body]

        return app(environ, start_response)

    return middleware


# -- Django ------------------------------------------------------------------------------


def django_license_middleware(gate: Gate, open_prefixes: Sequence[str] = ()) -> Any:
    """Build the Django middleware that closes a deployment while it is unlicensed."""
    from django.http import JsonResponse

    def factory(get_response: Callable[[Any], Any]) -> Callable[[Any], Any]:
        def middleware(request: Any) -> Any:
            if path_is_open(request.path, open_prefixes):
                return get_response(request)
            try:
                gate.require_usable()
            except LicenseDenied as denied:
                return JsonResponse(denied.body(), status=denied.http_status)
            return get_response(request)

        return middleware

    return factory


# -- Flask -------------------------------------------------------------------------------


def flask_register(app: Any, gate: Gate, open_prefixes: Sequence[str] = ()) -> None:
    """Close a Flask application while its license does not let it serve."""
    from flask import jsonify, request

    @app.before_request
    def _check() -> Any:
        if path_is_open(request.path, open_prefixes):
            return None
        try:
            gate.require_usable()
        except LicenseDenied as denied:
            return jsonify(denied.body()), denied.http_status
        return None

    @app.errorhandler(LicenseDenied)
    def _handle(denied: LicenseDenied) -> Any:
        return jsonify(denied.body()), denied.http_status
