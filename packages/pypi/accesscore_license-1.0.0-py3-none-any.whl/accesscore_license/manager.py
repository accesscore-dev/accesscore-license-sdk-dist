"""What ties the host's interfaces to the core.

It reads the store, asks the machine what it is, calls the core, and hands the answer to the
gate. It is the only module in the binding that touches both sides.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Sequence

from ._core import AclicCore, core as shared_core
from .gate import Gate, LicenseDenied
from .host import (
    ActivationServerDirectory,
    AuditRecorder,
    FeatureCatalogue,
    LifecycleEvent,
    ProductIdentity,
    QuotaCounter,
    Store,
)

__all__ = ["LicenseManager"]


def _rfc3339(moment: datetime) -> str:
    """Render an instant the way the payload writes one."""
    return moment.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _stored_record(record: dict[str, Any] | None) -> dict[str, Any] | None:
    """The part of a registration a judgement reads."""
    if record is None:
        return None
    return {
        key: value
        for key, value in {
            "licenseToken": record.get("licenseToken"),
            "verificationWatermark": record.get("verificationWatermark"),
            "lastHeartbeatAt": record.get("lastHeartbeatAt"),
            "revokedAt": record.get("revokedAt"),
        }.items()
        if value is not None
    }


def _normalize_server_url(url: str | None) -> str:
    """Strip trailing slashes so two forms of one address compare equal."""
    return (url or "").strip().rstrip("/")


class LicenseManager:
    """Everything a deployment needs to judge and to register itself."""

    def __init__(
        self,
        store: Store,
        identity: ProductIdentity,
        keys: Sequence[dict[str, str]],
        gate: Gate | None = None,
        core: AclicCore | None = None,
        catalogue: FeatureCatalogue | None = None,
        counters: Sequence[QuotaCounter] = (),
        audit: AuditRecorder | None = None,
        directory: ActivationServerDirectory | None = None,
        configured_server_url: str = "",
        instance_id: str | None = None,
    ) -> None:
        self._core = core or shared_core()
        self._gate = gate or Gate()
        self._store = store
        self._identity = identity
        self._keys = list(keys)
        self._catalogue = catalogue
        self._counters = list(counters)
        self._audit = audit
        self._directory = directory
        self._configured_server_url = _normalize_server_url(configured_server_url)
        self._instance_id = instance_id

    @property
    def gate(self) -> Gate:
        """The gate every request-time check goes through."""
        return self._gate

    @property
    def core(self) -> AclicCore:
        """The core, for a caller that needs an operation this class does not wrap."""
        return self._core

    # -- judgement -----------------------------------------------------------------------

    def verify(self, now: datetime, integrity_ok: bool = True) -> dict[str, Any]:
        """Judge the stored registration and publish the result to the gate.

        ``now`` and ``integrity_ok`` come from the host: the core reads no clock, and what to
        hash for an integrity check differs per language.
        """
        previous = self._gate.status()
        collected = self._core.fingerprint()

        response = self._core.evaluate(
            {
                "keys": self._keys,
                "storedRecord": _stored_record(self._store.load()),
                "now": _rfc3339(now),
                "integrityOk": integrity_ok,
                "productCode": self._identity.product_code(),
                "productRelease": self._identity.release(),
                "collectedFingerprints": collected.get("fingerprints", []),
            }
        )

        self._persist_watermark(response)
        self._gate.refresh(response)
        self._record_transition(previous, response)
        return response

    def apply(
        self, record: dict[str, Any], now: datetime, integrity_ok: bool = True
    ) -> dict[str, Any]:
        """Replace the stored registration and judge it."""
        self._store.save(record)
        return self.verify(now, integrity_ok)

    def mark_revoked(self, now: datetime, integrity_ok: bool = True) -> dict[str, Any]:
        """Record that the issuing server revoked this activation and judge again."""
        record = dict(self._store.load() or {})
        record["revokedAt"] = _rfc3339(now)
        self._store.save(record)
        if self._audit is not None:
            self._audit.lifecycle(LifecycleEvent.REVOKED, None, None)
        return self.verify(now, integrity_ok)

    def clear_registration(self, now: datetime, integrity_ok: bool = True) -> dict[str, Any]:
        """Discard the registration, returning the deployment to unregistered."""
        self._store.clear()
        return self.verify(now, integrity_ok)

    def fingerprint(self) -> dict[str, Any]:
        """What this machine reports about itself."""
        return self._core.fingerprint()

    # -- activation ----------------------------------------------------------------------

    def activation_request(self, product_key: str, now: datetime) -> dict[str, Any]:
        """Write the activation request the host sends."""
        return self._core.activation_request(
            {
                "operation": "ACTIVATE",
                "productKey": product_key,
                "productCode": self._identity.product_code(),
                "productRelease": self._identity.release(),
                "machineFingerprints": self.fingerprint().get("fingerprints", []),
                "instanceId": self._instance_id,
                "requestedAt": _rfc3339(now),
                "knownFeatures": self.gated_features(),
                "knownQuotas": self.counted_quotas(),
                "usage": {},
            }
        )

    def heartbeat_request(self, now: datetime) -> dict[str, Any]:
        """Write the heartbeat request the host sends."""
        record = self._store.load() or {}
        return self._core.activation_request(
            {
                "operation": "HEARTBEAT",
                "activationId": record.get("activationId"),
                "activationSecret": record.get("activationSecret"),
                "productCode": self._identity.product_code(),
                "productRelease": self._identity.release(),
                "machineFingerprints": self.fingerprint().get("fingerprints", []),
                "instanceId": record.get("instanceId") or self._instance_id,
                "requestedAt": _rfc3339(now),
                "knownFeatures": self.gated_features(),
                "knownQuotas": self.counted_quotas(),
                "usage": self.usage(),
            }
        )

    def deactivation_request(self, now: datetime) -> dict[str, Any]:
        """Write the release request the host sends, handing the seat back."""
        record = self._store.load() or {}
        return self._core.activation_request(
            {
                "operation": "DEACTIVATE",
                "activationId": record.get("activationId"),
                "activationSecret": record.get("activationSecret"),
                "machineFingerprints": self.fingerprint().get("fingerprints", []),
                "requestedAt": _rfc3339(now),
            }
        )

    def interpret(
        self,
        operation: str,
        status: int,
        body: str,
        nonce: str,
        reachable: bool = True,
    ) -> dict[str, Any]:
        """Read the answer the server gave.

        The token is checked against this deployment's key, this deployment's machine, and the
        nonce it just sent, before the host is told to store anything.
        """
        return self._core.activation_response(
            {
                "operation": operation,
                "status": status,
                "body": body,
                "nonce": nonce,
                "keys": [
                    {"kid": key["kid"], "publicKey": key["publicKey"]} for key in self._keys
                ],
                "collectedFingerprints": self.fingerprint().get("fingerprints", []),
                "reachable": reachable,
            }
        )

    def server_url(self) -> str:
        """The address to call, read per request rather than fixed at start."""
        if self._directory is None:
            return self._configured_server_url
        registered = _normalize_server_url(self._directory.server_url())
        return registered or self._configured_server_url

    # -- what this deployment can act on --------------------------------------------------

    def gated_features(self) -> list[str]:
        """The feature keys this deployment gates on."""
        return [] if self._catalogue is None else self._catalogue.gated_features()

    def counted_quotas(self) -> list[str]:
        """The quota codes this deployment can count."""
        codes: list[str] = []
        for counter in self._counters:
            codes.extend(counter.counted_quota_codes())
        return codes

    def usage(self) -> dict[str, int]:
        """What this deployment currently holds, per quota code."""
        usage: dict[str, int] = {}
        for counter in self._counters:
            for code in counter.counted_quota_codes():
                usage[code] = counter.count(code)
        return usage

    def check_quota(self, quota_code: str) -> None:
        """Check an addition against the ceiling, counting through the host's counters."""
        current = 0
        for counter in self._counters:
            if counter.supports(quota_code):
                current = counter.count(quota_code)
                break
        try:
            self._gate.check_quota(quota_code, current)
        except LicenseDenied:
            if self._audit is not None:
                limit = (self._gate.state().get("limits") or {}).get(quota_code, 0)
                self._audit.limit_reached(quota_code, current, int(limit))
            raise

    # -- internals -----------------------------------------------------------------------

    def _persist_watermark(self, response: dict[str, Any]) -> None:
        """Persist the watermark the judgement produced."""
        watermark = response.get("nextWatermark")
        if watermark is None:
            return
        record = self._store.load()
        if record is None:
            return
        if record.get("verificationWatermark") == watermark:
            return
        record = dict(record)
        record["verificationWatermark"] = watermark
        self._store.save(record)

    def _record_transition(self, previous: str, response: dict[str, Any]) -> None:
        """Record a status change, and only a change."""
        if self._audit is None or previous == response.get("status"):
            return
        payload = response.get("payload") or {}
        self._audit.status_changed(
            previous, response.get("status", ""), payload.get("licenseId")
        )
