"""The neutral gate.

Four operations, the same four in every language the SDK binds::

    gate.state()                     the cached judgement
    gate.require_feature(key)        refuse when the license does not grant it
    gate.check_quota(code, current)  refuse when the ceiling is passed
    gate.refresh(evaluation)         replace the cache with a fresh judgement

The binding holds the judgement; the host decides when to refresh it — at start, after a
successful activation, after a successful heartbeat, and on whatever schedule it keeps. The gate
that runs on every request reads this cache and never calls the core.
"""

from __future__ import annotations

import threading
from typing import Any, Callable, Iterable

__all__ = ["Gate", "LicenseDenied", "FORBIDDEN"]

#: The refusal an unlicensed or unentitled request gets. Not 401 — no credential would change
#: the answer.
FORBIDDEN = 403

#: The code a request refused for a feature the license does not grant carries.
FEATURE_NOT_LICENSED = "LICENSE_FEATURE_NOT_LICENSED"

#: The code a request refused for a feature an administrator switched off carries.
FEATURE_NOT_ACTIVATED = "LICENSE_FEATURE_NOT_ACTIVATED"

#: The code a request refused for passing a licensed ceiling carries.
QUOTA_EXCEEDED = "LICENSE_QUOTA_EXCEEDED"

_UNKNOWN: dict[str, Any] = {
    "status": "NOT_ACTIVATED",
    "usable": False,
    "errorCode": "LICENSE_NOT_ACTIVATED",
    "denial": {"messageKey": "error.license.notActivated", "arguments": []},
    "availableFeatures": [],
    "limits": {},
}


class LicenseDenied(Exception):
    """What a gate raises when it refuses a request.

    It carries a key and its arguments rather than a sentence. The SDK does not know the request
    locale, and a message the SDK wrote would need translating once per language it binds; the
    host already has a message resolver and its own locales.
    """

    def __init__(
        self,
        status: str,
        error_code: str,
        message_key: str,
        arguments: Iterable[Any] = (),
        http_status: int = FORBIDDEN,
    ) -> None:
        super().__init__(f"{error_code}: {message_key}")
        self.status = status
        self.error_code = error_code
        self.message_key = message_key
        self.arguments = list(arguments)
        self.http_status = http_status

    def body(self) -> dict[str, Any]:
        """The one document every adapter writes."""
        return {
            "errorCode": self.error_code,
            "status": self.status,
            "messageKey": self.message_key,
            "arguments": self.arguments,
        }


class Gate:
    """The gate every request-time check goes through."""

    def __init__(
        self, activation_checker: Callable[[str], bool] | None = None
    ) -> None:
        self._lock = threading.Lock()
        self._state: dict[str, Any] = dict(_UNKNOWN)
        self._activation_checker = activation_checker

    def state(self) -> dict[str, Any]:
        """The cached judgement."""
        with self._lock:
            return self._state

    def refresh(self, evaluation: dict[str, Any] | None) -> None:
        """Replace the cache with a fresh judgement."""
        with self._lock:
            self._state = dict(_UNKNOWN) if evaluation is None else evaluation

    def status(self) -> str:
        """What the judgement concluded."""
        return self.state().get("status", "NOT_ACTIVATED")

    def is_usable(self) -> bool:
        """Whether the deployment keeps operating."""
        return bool(self.state().get("usable", False))

    def require_usable(self) -> None:
        """Refuse when the deployment is not licensed to serve at all."""
        state = self.state()
        if state.get("usable"):
            return
        denial = state.get("denial") or {
            "messageKey": "error.license.notValid",
            "arguments": [],
        }
        raise LicenseDenied(
            state.get("status", "NOT_ACTIVATED"),
            state.get("errorCode", "LICENSE_NOT_ACTIVATED"),
            denial.get("messageKey", "error.license.notValid"),
            denial.get("arguments", []),
        )

    def require_feature(self, feature: str) -> None:
        """Refuse when the license does not grant a feature, or it is switched off."""
        self.require_usable()

        state = self.state()
        if feature not in (state.get("availableFeatures") or []):
            raise LicenseDenied(
                state.get("status", "VALID"),
                FEATURE_NOT_LICENSED,
                "error.license.featureNotLicensed",
                [feature],
            )
        if not self.is_activated(feature):
            raise LicenseDenied(
                state.get("status", "VALID"),
                FEATURE_NOT_ACTIVATED,
                "error.license.featureNotActivated",
                [feature],
            )

    def check_quota(self, quota_code: str, current: int) -> None:
        """Refuse when taking one more of something would pass its ceiling.

        The comparison is against the count after the addition, so a deployment holding exactly
        its ceiling is refused the next one rather than the one it already has.
        """
        self.require_usable()

        state = self.state()
        limits = state.get("limits") or {}
        if quota_code not in limits:
            return
        limit = int(limits[quota_code])
        if current + 1 <= limit:
            return
        raise LicenseDenied(
            state.get("status", "VALID"),
            QUOTA_EXCEEDED,
            "error.license.quotaExceeded",
            [quota_code, limit],
        )

    def is_licensed(self, feature: str) -> bool:
        """Whether the license grants a feature, ignoring activation."""
        return feature in (self.state().get("availableFeatures") or [])

    def is_activated(self, feature: str) -> bool:
        """Whether an administrator has switched a feature on."""
        if self._activation_checker is None:
            return True
        return bool(self._activation_checker(feature))

    def is_allowed(self, feature: str) -> bool:
        """Whether the license grants a feature and it is switched on."""
        return self.is_licensed(feature) and self.is_activated(feature)

    def effective_features(self) -> list[str]:
        """The features a client may act on: granted by the license and switched on.

        A client gates its navigation on this list, so it has to agree with the server-side
        gates — which it does, because both read it from here.
        """
        return [
            feature
            for feature in (self.state().get("availableFeatures") or [])
            if self.is_activated(feature)
        ]
