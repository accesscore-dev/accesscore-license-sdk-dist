"""The AccessCore license SDK for Python.

The judgement lives in one Rust core that every language binding calls; this package is the
Python wrapper over it, plus the neutral gate, the host interfaces, and the framework adapters.

Nothing here decides whether a license is valid. That is the core's, and it is the same core a
Java, Go, or Rust deployment runs — which is what stops two deployments from disagreeing about
one token.
"""

from ._core import AclicCore, AclicError, NativeLoadError, core
from .gate import FORBIDDEN, Gate, LicenseDenied
from .host import (
    ActivationServerDirectory,
    AuditRecorder,
    FeatureActivationChecker,
    FeatureCatalogue,
    LifecycleEvent,
    ProductIdentity,
    QuotaCounter,
    Store,
)
from .issuing import LicenseIssuer, ProductKeys, ReleaseVersions
from .manager import LicenseManager

__all__ = [
    "AclicCore",
    "AclicError",
    "ActivationServerDirectory",
    "AuditRecorder",
    "FORBIDDEN",
    "FeatureActivationChecker",
    "FeatureCatalogue",
    "Gate",
    "LicenseDenied",
    "LicenseIssuer",
    "LicenseManager",
    "LifecycleEvent",
    "NativeLoadError",
    "ProductIdentity",
    "ProductKeys",
    "QuotaCounter",
    "ReleaseVersions",
    "Store",
    "core",
]

def __getattr__(name: str) -> str:
    """Answers `__version__` with the version of the core actually loaded.

    Not a literal: the wheel is numbered after the core it carries, so asking the core is both
    the truthful answer and one fewer place to edit when the version changes.
    """
    if name == "__version__":
        return core().version()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
