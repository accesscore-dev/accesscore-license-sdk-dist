"""The native boundary, as Python calls it.

Everything above this module works in Python objects; everything below it is one C ABI. The
translation happens here and nowhere else, so a field added to the payload changes one loader
rather than every call site.

``cffi`` in ABI mode rather than API mode: the library is loaded at runtime from the wheel, so
installing the package compiles nothing and a wheel built once runs on every supported Python.
"""

from __future__ import annotations

import json
import platform
import sys
from pathlib import Path
from typing import Any

from cffi import FFI

__all__ = ["AclicCore", "AclicError", "NativeLoadError", "core"]

# The declarations the loader binds. A transcription of include/aclic.h, so a reader comparing
# the two does not have to translate between them.
_CDEF = """
int32_t  aclic_evaluate(const char* req_json, char** out_json);
int32_t  aclic_sign(const char* req_json, char** out_json);
int32_t  aclic_verify_signature(const char* req_json, char** out_json);
int32_t  aclic_fingerprint(char** out_json);
int32_t  aclic_fingerprint_compute(const char* req_json, char** out_json);
int32_t  aclic_activation_request(const char* req_json, char** out_json);
int32_t  aclic_activation_response(const char* res_json, char** out_json);
int32_t  aclic_generate_keypair(const char* req_json, char** out_json);
int32_t  aclic_product_key(const char* req_json, char** out_json);
int32_t  aclic_release(const char* req_json, char** out_json);
uint32_t aclic_schema_version(void);
const char* aclic_version(void);
void     aclic_string_free(char* s);
"""

ACLIC_OK = 0
ACLIC_NULL_ARGUMENT = -1
ACLIC_INVALID_UTF8 = -2
ACLIC_OPERATION_FAILED = -3
ACLIC_PANIC = -4

_CODE_REASONS = {
    ACLIC_NULL_ARGUMENT: "a required argument was null",
    ACLIC_INVALID_UTF8: "the request was not valid UTF-8",
    ACLIC_OPERATION_FAILED: "the operation produced no result",
    ACLIC_PANIC: "the license core failed",
}


class NativeLoadError(RuntimeError):
    """Raised when the license core cannot be found or loaded."""


class AclicError(RuntimeError):
    """Raised when a call across the boundary did not produce a result."""

    def __init__(self, operation: str, message: str) -> None:
        super().__init__(f"{operation}: {message}")
        self.operation = operation


def _platform_directory() -> str:
    """Name the directory this machine's library sits in."""
    system = sys.platform
    if system.startswith("darwin"):
        name = "darwin"
    elif system.startswith("win"):
        name = "windows"
    else:
        name = "linux"

    machine = platform.machine().lower()
    if machine in ("arm64", "aarch64"):
        architecture = "aarch64"
    elif machine in ("x86_64", "amd64"):
        architecture = "x86_64"
    else:
        architecture = machine

    return f"{name}-{architecture}"


def _library_file_name() -> str:
    """Name the library file on this platform."""
    if sys.platform.startswith("darwin"):
        return "libaclic.dylib"
    if sys.platform.startswith("win"):
        return "aclic.dll"
    return "libaclic.so"


def _library_path() -> Path:
    """Find the library this platform loads.

    A path may be named with ``ACLIC_NATIVE_LIBRARY`` for a deployment whose own policy fixes
    where a shared library may come from. It names a file to load, never a key to trust, so it
    cannot weaken any check.
    """
    import os

    named = os.environ.get("ACLIC_NATIVE_LIBRARY", "").strip()
    if named:
        return Path(named)

    return Path(__file__).parent / "native" / _platform_directory() / _library_file_name()


class AclicCore:
    """The license core, loaded once and called many times.

    The core holds no state between calls — every judgement is a function of what it was handed
    — so one instance serves a whole process.
    """

    def __init__(self, library_path: Path | None = None) -> None:
        path = library_path or _library_path()
        if not path.exists():
            raise NativeLoadError(
                f"The license core is not present at {path}. Build it with "
                f"scripts/build-native.sh, or name an existing library with "
                f"ACLIC_NATIVE_LIBRARY."
            )
        self._ffi = FFI()
        self._ffi.cdef(_CDEF)
        try:
            self._library = self._ffi.dlopen(str(path))
        except OSError as error:
            raise NativeLoadError(
                f"The license core at {path} could not be loaded on "
                f"{_platform_directory()}."
            ) from error

    # -- boundary ------------------------------------------------------------------------

    def _call(self, function: Any, request: Any, operation: str) -> Any:
        """Send one request across the boundary and read the answer."""
        encoded = json.dumps(request, default=str).encode("utf-8")
        out = self._ffi.new("char**")
        code = function(encoded, out)
        return self._read(code, out, operation)

    def _call_without_request(self, function: Any, operation: str) -> Any:
        """Call a boundary function that takes nothing."""
        out = self._ffi.new("char**")
        code = function(out)
        return self._read(code, out, operation)

    def _read(self, code: int, out: Any, operation: str) -> Any:
        """Read an answer and free the memory the core handed over."""
        answer = None
        try:
            if out[0] != self._ffi.NULL:
                answer = self._ffi.string(out[0]).decode("utf-8")
        finally:
            # Freed whatever the outcome: the core allocated it, and a failure path that
            # skipped the free would leak a little on every refusal.
            if out[0] != self._ffi.NULL:
                self._library.aclic_string_free(out[0])

        if code != ACLIC_OK:
            reason = _CODE_REASONS.get(code, f"the license core returned {code}")
            raise AclicError(operation, reason if answer is None else f"{reason}: {answer}")
        if answer is None:
            raise AclicError(operation, "the core returned no answer")
        return json.loads(answer)

    # -- operations ----------------------------------------------------------------------

    def evaluate(self, request: dict) -> dict:
        """Judge everything a host knows about its license."""
        return self._call(self._library.aclic_evaluate, request, "evaluate")

    def sign(self, request: dict) -> dict:
        """Sign a payload into a token, or read which key pair a key belongs to."""
        return self._call(self._library.aclic_sign, request, "sign")

    def verify_signature(self, request: dict) -> dict:
        """Check a token's signature without judging anything else about it."""
        return self._call(self._library.aclic_verify_signature, request, "verifySignature")

    def fingerprint(self) -> dict:
        """Read what this machine reports about itself."""
        return self._call_without_request(self._library.aclic_fingerprint, "fingerprint")

    def fingerprint_compute(self, request: dict) -> dict:
        """Hash machine identifiers, and match them against what a license names."""
        return self._call(
            self._library.aclic_fingerprint_compute, request, "fingerprintCompute"
        )

    def activation_request(self, request: dict) -> dict:
        """Write the activation, heartbeat, or release request a host sends."""
        return self._call(
            self._library.aclic_activation_request, request, "activationRequest"
        )

    def activation_response(self, response: dict) -> dict:
        """Read the answer an activation server gave."""
        return self._call(
            self._library.aclic_activation_response, response, "activationResponse"
        )

    def generate_keypair(self, request: dict) -> dict:
        """Generate a signing key pair."""
        return self._call(
            self._library.aclic_generate_keypair, request, "generateKeyPair"
        )

    def product_key(self, request: dict) -> dict:
        """Generate and read customer-facing product keys."""
        return self._call(self._library.aclic_product_key, request, "productKey")

    def release(self, request: dict) -> dict:
        """Rank release versions and check them against a ceiling."""
        return self._call(self._library.aclic_release, request, "release")

    def schema_version(self) -> int:
        """The payload schema number this build reads and writes."""
        return int(self._library.aclic_schema_version())

    def version(self) -> str:
        """The SDK version the loaded core reports."""
        pointer = self._library.aclic_version()
        if pointer == self._ffi.NULL:
            return ""
        return self._ffi.string(pointer).decode("utf-8")


_shared: AclicCore | None = None


def core() -> AclicCore:
    """The shared core, loading the library on first use."""
    global _shared
    if _shared is None:
        _shared = AclicCore()
    return _shared
