"""What the host supplies.

The core reads no file, opens no socket, and counts nothing. Everything it needs that lives
outside a pure function arrives through one of these, contributed by the product.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any

__all__ = [
    "ActivationServerDirectory",
    "AuditRecorder",
    "FeatureActivationChecker",
    "FeatureCatalogue",
    "LifecycleEvent",
    "ProductIdentity",
    "QuotaCounter",
    "Store",
]


class Store(ABC):
    """Reading and writing this deployment's registration.

    The SDK does not know how a product persists anything, so the product contributes the store.
    A database row that survives container replacement and a file on a mounted volume are both
    valid answers, and the SDK has no opinion between them.
    """

    @abstractmethod
    def load(self) -> dict[str, Any] | None:
        """The persisted registration, or None when nothing is registered."""

    @abstractmethod
    def save(self, record: dict[str, Any]) -> None:
        """Persist a registration, replacing whatever was stored before."""

    @abstractmethod
    def clear(self) -> None:
        """Remove the registration, returning the deployment to unregistered."""


class QuotaCounter(ABC):
    """The current count for a licensed quota.

    The SDK knows the ceilings but not how the things being counted are modelled, so the product
    contributes counters — one per area, each answering only for the codes it owns. A quota
    nothing answers for is not enforced, and that is said once at start rather than let through
    silently.
    """

    @abstractmethod
    def counted_quota_codes(self) -> list[str]:
        """The quota codes this counter answers for."""

    @abstractmethod
    def count(self, quota_code: str) -> int:
        """The current count for a code this counter supports."""

    def supports(self, quota_code: str) -> bool:
        """Whether this counter answers for a code."""
        return quota_code in self.counted_quota_codes()


class FeatureCatalogue(ABC):
    """Every feature key this deployment actually gates on.

    The keys are scattered across the product's gates, so nothing in the SDK can enumerate them.
    What the list is for is reconciliation: the issuer sells modules by key and cannot know which
    of them a given deployment can act on, and a key that was sold but is gated nowhere earns a
    customer nothing.
    """

    @abstractmethod
    def gated_features(self) -> list[str]:
        """The feature keys this deployment gates on."""


class ProductIdentity(ABC):
    """Which product this deployment is, and which release runs here.

    This comes from code, never from configuration. A deployment that could edit its own product
    code could accept a license issued for another product, and the issuer signs every product
    with one key.
    """

    @abstractmethod
    def product_code(self) -> str:
        """The product code, matching the code the issuer's catalogue carries."""

    @abstractmethod
    def release(self) -> str:
        """The running release, reported at activation and checked against the ceiling."""


class FeatureActivationChecker(ABC):
    """Whether a licensed feature is effectively active.

    The license grants permission; an administrator grants activation. A billable add-on is
    effectively active only when both say so.
    """

    @abstractmethod
    def is_effectively_active(self, feature: str) -> bool:
        """Whether the feature is effectively active."""


class LifecycleEvent(str, Enum):
    """The registration lifecycle events worth a record."""

    ACTIVATED = "ACTIVATED"
    DEACTIVATED = "DEACTIVATED"
    HEARTBEAT = "HEARTBEAT"
    REVOKED = "REVOKED"


class AuditRecorder(ABC):
    """Recording license events into the product's audit trail.

    An implementation must not let a recording failure reach its caller. Judgement runs at start
    and on a schedule, and a failed audit write may never change what a deployment concludes
    about its license.
    """

    @abstractmethod
    def status_changed(self, previous: str, current: str, license_id: str | None) -> None:
        """Record a change in status. Only a transition is worth a row."""

    @abstractmethod
    def lifecycle(
        self, event: LifecycleEvent, license_id: str | None, detail: str | None
    ) -> None:
        """Record a registration lifecycle event."""

    @abstractmethod
    def limit_reached(self, quota_code: str, current: int, limit: int) -> None:
        """Record an operation refused because a licensed ceiling was reached."""


class ActivationServerDirectory(ABC):
    """Where this deployment reaches its activation server.

    Configuration alone cannot answer this. A deployment is installed before anyone decides which
    server it belongs to — often by someone holding the address on a printed page and with no way
    to edit a file on the host — so the address has to be settable while the product runs and has
    to survive a restart.
    """

    @abstractmethod
    def server_url(self) -> str | None:
        """The address to use, or None to fall back to the configured one."""
