package dev.accesscore.license.sdk.issuing;

import dev.accesscore.license.sdk.ffi.AclicCore;

import java.util.HashMap;
import java.util.Map;

/**
 * How a release version is ranked, for both sides of a license.
 *
 * <p>The issuer decides whether a reported release is above a contract's ceiling and the
 * deployment decides the same thing about itself. Two implementations would agree on
 * {@code 3.2} and {@code 4.0} and disagree on {@code 3.2} and {@code 3.2.0}, and that kind of
 * disagreement only shows up at a customer site — so the comparison crosses to the core rather
 * than being written once per language.
 */
public final class ReleaseVersions {

    /** The longest sort key {@link #sortKey} produces, and the column width a ledger needs. */
    public static final int SORT_KEY_MAX_LENGTH = 128;

    private final AclicCore core;

    /**
     * Uses the shared core.
     */
    public ReleaseVersions() {
        this(AclicCore.shared());
    }

    /**
     * @param core the core to call
     */
    public ReleaseVersions(AclicCore core) {
        this.core = core;
    }

    /**
     * Ranks two versions.
     *
     * @param left one version, null or blank ranking below everything
     * @param right the other version
     * @return negative when left ranks below right, zero when they are the same release,
     *         positive otherwise
     */
    public int compare(String left, String right) {
        Map<String, Object> request = new HashMap<>();
        request.put("operation", "COMPARE");
        request.put("version", nullToEmpty(left));
        request.put("other", nullToEmpty(right));
        return core.release(request).path("result").asInt();
    }

    /**
     * Whether a release is allowed by a ceiling.
     *
     * @param release the release being run or reported
     * @param ceiling the highest release entitled, null or blank meaning no ceiling
     * @return whether the release is at or below the ceiling
     */
    public boolean isWithinCeiling(String release, String ceiling) {
        Map<String, Object> request = new HashMap<>();
        request.put("operation", "WITHIN_CEILING");
        request.put("version", nullToEmpty(release));
        request.put("other", ceiling);
        return core.release(request).path("result").asBoolean(false);
    }

    /**
     * The normalized form a list of releases is ordered by in SQL.
     *
     * <p>The key is a reading aid, not the rule: for versions carrying a pre-release suffix it
     * groups them beside their base version without promising the exact order
     * {@link #compare} gives them. Every judgement that decides entitlement calls
     * {@link #compare}.
     *
     * @param version the version to normalize, null or blank producing the lowest key
     * @return the sort key, never longer than {@link #SORT_KEY_MAX_LENGTH}
     */
    public String sortKey(String version) {
        Map<String, Object> request = new HashMap<>();
        request.put("operation", "SORT_KEY");
        request.put("version", nullToEmpty(version));
        return core.release(request).path("result").asText();
    }

    /**
     * @param value a value that may be absent
     * @return the value, or an empty string
     */
    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
