package dev.accesscore.license.sdk.issuing;

import com.fasterxml.jackson.databind.JsonNode;
import dev.accesscore.license.sdk.ffi.AclicCore;

import java.util.Map;

/**
 * The customer-facing key an operator types to activate a deployment.
 *
 * <p>Written as {@code <PREFIX>-XXXXX-XXXXX-XXXXX-XXXXX-XXXXX} over an alphabet that drops the
 * characters people confuse when copying by hand ({@code I}, {@code L}, {@code O}, {@code U}).
 * The last group is a checksum over the rest, so a typo is caught where it is typed instead of
 * turning into a puzzling "unknown product key" from the server.
 *
 * <p>Both halves of licensing need this and they have to agree: the ledger writes the keys, and
 * a deployment shows the operator which key it runs on. A Java copy of the alphabet and the
 * checksum would be a second definition of the format, so every operation crosses to the core.
 *
 * <p>The prefix is an argument rather than a constant. It names a product family, and a product
 * vocabulary compiled into the SDK would make one product's key format everyone's.
 */
public final class ProductKeys {

    private final AclicCore core;

    /**
     * Uses the shared core.
     */
    public ProductKeys() {
        this(AclicCore.shared());
    }

    /**
     * @param core the core to call
     */
    public ProductKeys(AclicCore core) {
        this.core = core;
    }

    /**
     * @param prefix the product-family prefix
     * @return a fresh key, grouped and checksummed
     */
    public String generate(String prefix) {
        return text(core.productKey(Map.of("operation", "GENERATE", "prefix", prefix)));
    }

    /**
     * @param prefix the product-family prefix
     * @param candidate a key as typed, in any case and with or without separators
     * @return whether it is well formed and its checksum matches
     */
    public boolean isValid(String prefix, String candidate) {
        JsonNode answer = core.productKey(
                Map.of("operation", "VALIDATE", "prefix", prefix, "key", nullToEmpty(candidate)));
        return answer.path("valid").asBoolean(false);
    }

    /**
     * @param prefix the product-family prefix
     * @param candidate a key as typed
     * @return the canonical grouped form, or null when the value is not well formed
     */
    public String canonical(String prefix, String candidate) {
        return text(core.productKey(
                Map.of("operation", "CANONICAL", "prefix", prefix, "key", nullToEmpty(candidate))));
    }

    /**
     * The key rendered for display: its leading group and its checksum group, middle withheld.
     *
     * <p>An operator answering "we lost our key" holds one rendering in a support request and
     * matches it against the other, which only works because both sides render the same ends
     * the same way.
     *
     * <p>A value not in the issued shape is withheld entirely rather than shown as it stands —
     * guessing at how to mask an unexpected string risks printing the key in full.
     *
     * @param prefix the product-family prefix
     * @param candidate a key as issued
     * @return the masked key, null when the value is absent or not well formed
     */
    public String masked(String prefix, String candidate) {
        return text(core.productKey(
                Map.of("operation", "MASK", "prefix", prefix, "key", nullToEmpty(candidate))));
    }

    /**
     * @param answer what the core returned
     * @return the key it carries, or null when it carries none
     */
    private static String text(JsonNode answer) {
        JsonNode key = answer.path("key");
        return key.isNull() || key.isMissingNode() ? null : key.asText();
    }

    /**
     * @param value a value that may be absent
     * @return the value, or an empty string
     */
    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
