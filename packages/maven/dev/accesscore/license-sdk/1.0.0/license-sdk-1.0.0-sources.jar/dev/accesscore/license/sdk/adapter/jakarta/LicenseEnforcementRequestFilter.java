package dev.accesscore.license.sdk.adapter.jakarta;

import dev.accesscore.license.sdk.adapter.DenialBody;
import dev.accesscore.license.sdk.gate.LicenseDeniedException;
import dev.accesscore.license.sdk.gate.LicenseGate;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;

/**
 * Closes a Jakarta REST deployment while its license does not let it serve.
 *
 * <p>Which paths stay open is the product's decision: a deployment has to reach its own license
 * screen in order to stop being unlicensed. The patterns are prefixes rather than Ant patterns,
 * because Jakarta REST hands the filter a path relative to the application root and a prefix is
 * the whole of what this needs to decide.
 */
public class LicenseEnforcementRequestFilter implements ContainerRequestFilter {

    private final LicenseGate gate;
    private final List<String> openPrefixes;

    /**
     * @param gate the gate every enforcement point reads
     * @param openPrefixes path prefixes that stay reachable while the deployment is unlicensed
     */
    public LicenseEnforcementRequestFilter(LicenseGate gate, List<String> openPrefixes) {
        this.gate = gate;
        this.openPrefixes = List.copyOf(openPrefixes);
    }

    @Override
    public void filter(ContainerRequestContext context) {
        String path = "/" + context.getUriInfo().getPath();
        for (String prefix : openPrefixes) {
            if (path.startsWith(prefix)) {
                return;
            }
        }

        try {
            gate.requireUsable();
        } catch (LicenseDeniedException denied) {
            context.abortWith(Response.status(denied.httpStatus())
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .entity(DenialBody.of(denied).asMap())
                    .build());
        }
    }
}
