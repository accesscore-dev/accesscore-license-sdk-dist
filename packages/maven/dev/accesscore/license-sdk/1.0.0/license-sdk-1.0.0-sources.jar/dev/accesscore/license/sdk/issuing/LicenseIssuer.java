package dev.accesscore.license.sdk.issuing;

import dev.accesscore.license.sdk.ffi.AclicCore;
import dev.accesscore.license.sdk.model.LicenseModel.GeneratedKeyPair;
import dev.accesscore.license.sdk.model.LicenseModel.KeyMaterial;
import dev.accesscore.license.sdk.model.LicenseModel.LicensePayload;
import dev.accesscore.license.sdk.model.LicenseModel.SignatureCheck;
import dev.accesscore.license.sdk.model.LicenseModel.SignedToken;
import dev.accesscore.license.sdk.model.SignatureAlgorithm;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The issuing side, as Java calls it.
 *
 * <p>Only an issuer holds a private key, and only an issuer calls this. A deployment that
 * verifies tokens has the class on its classpath and nothing to do with it: signing needs a key
 * a customer never holds, so its presence grants nothing.
 *
 * <p>What it does not do is decide anything about a license. Which contract a token is issued
 * under, which seat it takes, and what it grants are the ledger's business; this turns a
 * decision already made into signed bytes.
 */
public class LicenseIssuer {

    private final AclicCore core;

    /**
     * Uses the shared core.
     */
    public LicenseIssuer() {
        this(AclicCore.shared());
    }

    /**
     * @param core the core to call
     */
    public LicenseIssuer(AclicCore core) {
        this.core = core;
    }

    /**
     * Signs a payload into a license token.
     *
     * <p>The key is handed over as PKCS#8 and wiped from the core's memory as soon as the
     * signature exists. Whatever copy the caller holds is the caller's to clear.
     *
     * @param payload the payload to sign
     * @param privateKeyPem the signing key, as a PKCS#8 PEM document
     * @return the token and the fingerprint of the key pair it was signed with
     */
    public SignedToken sign(LicensePayload payload, String privateKeyPem) {
        Map<String, Object> request = new HashMap<>();
        request.put("payload", payload);
        request.put("privateKey", privateKeyPem);
        return core.sign(request, SignedToken.class);
    }

    /**
     * What a signing key is, without signing anything with it.
     *
     * <p>An issuing server needs this before it has anything to sign: it announces which key
     * pair it issues for as it starts, and prints the public half an operator has to build into
     * a deployment.
     *
     * @param privateKeyPem the signing key
     * @return the fingerprint, the algorithm, and the verification half
     */
    public SignedToken describeKey(String privateKeyPem) {
        return core.sign(Map.of("privateKey", privateKeyPem), SignedToken.class);
    }

    /**
     * The fingerprint of the key pair a signing key belongs to.
     *
     * <p>What a deployment compares against the public key compiled into its own binary. Two
     * different values mean every license issued here would be refused there as unverifiable —
     * a mismatch worth finding while an operator is still typing the server address, not at the
     * first activation attempt.
     *
     * <p>Disclosing it costs nothing: the public half already ships inside every deployment,
     * and a digest turns back into no key material at all.
     *
     * @param privateKeyPem the signing key
     * @return the fingerprint, rendered as {@code SHA256:<base64url>}
     */
    public String fingerprintOf(String privateKeyPem) {
        return describeKey(privateKeyPem).fingerprint();
    }

    /**
     * Checks a token's signature without judging anything else about it.
     *
     * <p>What an issuer uses to confirm that what it just signed is what a deployment will
     * read. Nothing that decides entitlement stops here — that is the judgement.
     *
     * @param token the token to check
     * @param keys the keys to check it against
     * @return whether the signature checks out, and what the token carries
     */
    public SignatureCheck verify(String token, List<KeyMaterial> keys) {
        return core.verifySignature(Map.of("token", token, "keys", keys), SignatureCheck.class);
    }

    /**
     * Reads what a token grants, without checking its signature.
     *
     * <p>For inspecting what was issued. Nothing that decides entitlement calls it.
     *
     * @param token the token to read
     * @return the payload, or null when the token could not be read
     */
    public LicensePayload readPayload(String token) {
        return verify(token, List.of()).payload();
    }

    /**
     * Generates a signing key pair.
     *
     * <p>The private half never leaves the issuing environment. The public half is what a
     * deployment carries, fixed in its binary at a location it cannot redirect.
     *
     * @param algorithm which algorithm to generate for
     * @return the key pair and the fingerprint that identifies it
     */
    public GeneratedKeyPair generateKeyPair(SignatureAlgorithm algorithm) {
        return core.generateKeyPair(Map.of("algorithm", algorithm.wireName()),
                GeneratedKeyPair.class);
    }
}
