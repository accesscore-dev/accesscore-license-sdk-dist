package dev.accesscore.license.sdk.ffi;

import com.sun.jna.Native;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Set;

/**
 * Finds the license core and loads it.
 *
 * <p>The library travels inside the jar, one directory per platform, and is extracted to a
 * temporary file the first time it is needed. Shipping it in the jar is what makes the SDK one
 * artifact: a consumer adds a dependency rather than installing something beside their
 * application.
 *
 * <p>A path may be named with {@code aclic.native.library} for a deployment that has to load a
 * library from a location its own policy fixes — a read-only container that permits no
 * extraction, an operator who audits the binary separately. It names a file to load, never a
 * key to trust, so it cannot weaken any check.
 */
public final class NativeLibraryLoader {

    /** Where a deployment may name the library file rather than have it extracted. */
    public static final String LIBRARY_PATH_PROPERTY = "aclic.native.library";

    /** Where each platform's library sits inside the jar. */
    private static final String RESOURCE_ROOT = "/dev/accesscore/license/sdk/native";

    /** Owner-only, so an extracted library cannot be replaced by another user mid-run. */
    private static final Set<java.nio.file.attribute.PosixFilePermission> OWNER_ONLY = Set.of(
            java.nio.file.attribute.PosixFilePermission.OWNER_READ,
            java.nio.file.attribute.PosixFilePermission.OWNER_WRITE,
            java.nio.file.attribute.PosixFilePermission.OWNER_EXECUTE);

    private NativeLibraryLoader() {
    }

    /**
     * Loads the core and binds it to the C ABI declaration.
     *
     * @return the loaded library
     * @throws NativeLoadException when no library for this platform could be loaded
     */
    public static AclicLibrary load() {
        String named = System.getProperty(LIBRARY_PATH_PROPERTY);
        if (named != null && !named.isBlank()) {
            return bind(Path.of(named.trim()));
        }
        return bind(extract());
    }

    /**
     * @param libraryPath the library file
     * @return the library bound to the C ABI declaration
     */
    private static AclicLibrary bind(Path libraryPath) {
        if (!Files.isReadable(libraryPath)) {
            throw new NativeLoadException(
                    "The license core is not readable at " + libraryPath.toAbsolutePath()
                            + ". Build it with scripts/build-native.sh, or name an existing "
                            + "library with -D" + LIBRARY_PATH_PROPERTY + "=<path>.");
        }
        try {
            return Native.load(libraryPath.toAbsolutePath().toString(), AclicLibrary.class);
        } catch (UnsatisfiedLinkError e) {
            throw new NativeLoadException(
                    "The license core at " + libraryPath.toAbsolutePath()
                            + " could not be loaded on this platform (" + platform() + ").", e);
        }
    }

    /**
     * Writes this platform's library out of the jar.
     *
     * @return where it was written
     */
    private static Path extract() {
        String platform = platform();
        String resource = RESOURCE_ROOT + "/" + platform + "/" + libraryFileName();

        try (InputStream stream = NativeLibraryLoader.class.getResourceAsStream(resource)) {
            if (stream == null) {
                throw new NativeLoadException(
                        "This build of the license SDK carries no core for " + platform
                                + " (looked for " + resource + "). A release carries linux "
                                + "x86_64 (gnu and musl), linux aarch64, macOS aarch64 and "
                                + "x86_64, and windows x86_64.");
            }

            Path directory = Files.createTempDirectory("aclic-");
            directory.toFile().deleteOnExit();
            Path library = directory.resolve(libraryFileName());
            Files.copy(stream, library, StandardCopyOption.REPLACE_EXISTING);
            library.toFile().deleteOnExit();
            restrictToOwner(library);
            return library;
        } catch (IOException e) {
            throw new UncheckedIOException("The license core could not be extracted", e);
        }
    }

    /**
     * @param path the extracted library
     */
    private static void restrictToOwner(Path path) throws IOException {
        if (!path.getFileSystem().supportedFileAttributeViews().contains("posix")) {
            return;
        }
        Files.setPosixFilePermissions(path, OWNER_ONLY);
    }

    /**
     * @return the platform directory this machine reads from
     */
    public static String platform() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        String arch = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);

        String platformOs;
        if (os.contains("mac") || os.contains("darwin")) {
            platformOs = "darwin";
        } else if (os.contains("win")) {
            platformOs = "windows";
        } else {
            platformOs = "linux";
        }

        String platformArch = switch (arch) {
            case "aarch64", "arm64" -> "aarch64";
            case "x86_64", "amd64" -> "x86_64";
            default -> arch;
        };

        return platformOs + "-" + platformArch;
    }

    /**
     * @return what the library file is called on this platform
     */
    private static String libraryFileName() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (os.contains("mac") || os.contains("darwin")) {
            return "libaclic.dylib";
        }
        if (os.contains("win")) {
            return "aclic.dll";
        }
        return "libaclic.so";
    }

    /** Raised when the core cannot be found or loaded. */
    public static class NativeLoadException extends RuntimeException {

        /**
         * @param message what could not be loaded, and what to do about it
         */
        public NativeLoadException(String message) {
            super(message);
        }

        /**
         * @param message what could not be loaded, and what to do about it
         * @param cause the underlying failure
         */
        public NativeLoadException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
