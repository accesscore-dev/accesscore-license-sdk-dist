package dev.accesscore.license.sdk.adapter.webflux;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import dev.accesscore.license.sdk.adapter.DenialBody;
import dev.accesscore.license.sdk.gate.LicenseDeniedException;
import dev.accesscore.license.sdk.gate.LicenseGate;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Closes a WebFlux deployment while its license does not let it serve.
 *
 * <p>The same decision the Spring MVC filter makes, moved into a reactive response. Both call
 * the same gate and write the same document, which is what the adapter contract tests assert.
 */
public class LicenseEnforcementWebFilter implements WebFilter {

    private final LicenseGate gate;
    private final List<String> openPatterns;
    private final ObjectMapper objectMapper;
    private final AntPathMatcher matcher = new AntPathMatcher();

    /**
     * @param gate the gate every enforcement point reads
     * @param openPatterns the paths that stay reachable while the deployment is unlicensed
     * @param objectMapper how the refusal body is written
     */
    public LicenseEnforcementWebFilter(LicenseGate gate, List<String> openPatterns,
                                       ObjectMapper objectMapper) {
        this.gate = gate;
        this.openPatterns = List.copyOf(openPatterns);
        this.objectMapper = objectMapper;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String path = exchange.getRequest().getPath().pathWithinApplication().value();
        for (String pattern : openPatterns) {
            if (matcher.match(pattern, path)) {
                return chain.filter(exchange);
            }
        }

        try {
            gate.requireUsable();
        } catch (LicenseDeniedException denied) {
            return write(exchange.getResponse(), denied);
        }
        return chain.filter(exchange);
    }

    /**
     * @param response the response to write the refusal to
     * @param denied what the gate refused
     * @return the completed write
     */
    private Mono<Void> write(ServerHttpResponse response, LicenseDeniedException denied) {
        response.setStatusCode(statusOf(denied));
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);

        byte[] bytes;
        try {
            bytes = objectMapper.writeValueAsBytes(DenialBody.of(denied).asMap());
        } catch (JsonProcessingException e) {
            // The document is a record of strings; a failure here is not something a request
            // can recover from, and answering with an empty body would hide the refusal.
            return Mono.error(e);
        }
        DataBuffer buffer = response.bufferFactory().wrap(bytes);
        response.getHeaders().setContentLength(bytes.length);
        response.getHeaders().setAcceptCharset(List.of(StandardCharsets.UTF_8));
        return response.writeWith(Mono.just(buffer));
    }

    /**
     * @param denied what the gate refused
     * @return the status to answer with
     */
    private static HttpStatusCode statusOf(LicenseDeniedException denied) {
        HttpStatusCode status = HttpStatusCode.valueOf(denied.httpStatus());
        return status == null ? HttpStatus.FORBIDDEN : status;
    }
}
