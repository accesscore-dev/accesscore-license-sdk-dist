package dev.accesscore.license.sdk.issuing;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.Instant;
import java.util.List;

/**
 * The machines and nonce an issuance is stamped with.
 *
 * <p>Field for field the shape a deployment's activation request carries, so the offline path —
 * an operator carrying a request file to the issuing side — feeds the same issuance code as the
 * online one. From the issuer's side, a file and a socket are the same request.
 *
 * @param productKey the customer-facing key
 * @param machineFingerprints the machines the license is to be bound to
 * @param instanceId the deployment's stable identifier
 * @param productCode which product the deployment is
 * @param productRelease the release running there
 * @param nonce the value stamped into the issued payload, letting the issuing side detect a
 *        request that has already been served
 * @param requestedAt when the deployment created the request
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ActivationBinding(
        String productKey,
        List<String> machineFingerprints,
        String instanceId,
        String productCode,
        String productRelease,
        String nonce,
        Instant requestedAt
) {

    /**
     * @param machineFingerprints the machines to bind to
     * @param nonce the nonce to echo, may be null
     * @return a binding carrying only what stamping needs
     */
    public static ActivationBinding of(List<String> machineFingerprints, String nonce) {
        return new ActivationBinding(null, machineFingerprints, null, null, null, nonce, null);
    }
}
