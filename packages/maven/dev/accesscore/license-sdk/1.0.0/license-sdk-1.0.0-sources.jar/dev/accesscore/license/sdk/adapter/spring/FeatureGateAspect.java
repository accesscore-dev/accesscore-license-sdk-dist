package dev.accesscore.license.sdk.adapter.spring;

import dev.accesscore.license.sdk.adapter.RequiresFeature;
import dev.accesscore.license.sdk.gate.LicenseGate;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;

/**
 * Enforces {@link RequiresFeature} on Spring beans.
 *
 * <p>A method annotation wins over a class annotation, so a controller gated as a whole can
 * still hold one endpoint that needs a different feature.
 *
 * <p>The aspect refuses by letting the gate throw. Turning that into a response belongs to
 * whatever handles the exception, which keeps one refusal shape across every surface.
 */
@Aspect
public class FeatureGateAspect {

    private final LicenseGate gate;

    /**
     * @param gate the gate every enforcement point reads
     */
    public FeatureGateAspect(LicenseGate gate) {
        this.gate = gate;
    }

    /**
     * Checks the feature a method needs before it runs.
     *
     * @param joinPoint the call being made
     */
    @Before("@within(dev.accesscore.license.sdk.adapter.RequiresFeature) "
            + "|| @annotation(dev.accesscore.license.sdk.adapter.RequiresFeature)")
    public void requireFeature(JoinPoint joinPoint) {
        RequiresFeature required = resolve(joinPoint);
        if (required != null) {
            gate.requireFeature(required.value());
        }
    }

    /**
     * @param joinPoint the call being made
     * @return the annotation that governs it, method before class
     */
    private RequiresFeature resolve(JoinPoint joinPoint) {
        if (joinPoint.getSignature() instanceof MethodSignature signature) {
            Method method = signature.getMethod();
            RequiresFeature onMethod = method.getAnnotation(RequiresFeature.class);
            if (onMethod != null) {
                return onMethod;
            }
        }
        return joinPoint.getTarget().getClass().getAnnotation(RequiresFeature.class);
    }
}
