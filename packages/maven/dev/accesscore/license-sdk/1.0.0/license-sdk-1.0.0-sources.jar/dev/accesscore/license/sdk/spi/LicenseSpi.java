package dev.accesscore.license.sdk.spi;

import dev.accesscore.license.sdk.model.LicenseModel.RegistrationRecord;
import dev.accesscore.license.sdk.model.LicenseStatus;

import java.util.List;
import java.util.Optional;

/**
 * What the host supplies.
 *
 * <p>The core reads no file, opens no socket, and counts nothing. Everything it needs that
 * lives outside a pure function arrives through one of these, contributed by the product.
 *
 * <p>They are gathered in one file because they are one contract: a product implementing the
 * SDK reads the whole list once and knows exactly what it owes.
 */
public final class LicenseSpi {

    private LicenseSpi() {
    }

    /**
     * Reading and writing this deployment's registration.
     *
     * <p>The SDK does not know how a product persists anything, so the product contributes the
     * store. A database row that survives container replacement and a file on a mounted volume
     * are both valid answers, and the SDK has no opinion between them.
     */
    public interface LicenseStore {

        /**
         * @return the persisted registration, or empty when nothing is registered
         */
        Optional<RegistrationRecord> load();

        /**
         * Persists a registration, replacing whatever was stored before.
         *
         * @param record the registration to persist
         */
        void save(RegistrationRecord record);

        /**
         * Removes the registration, returning the deployment to its unregistered condition.
         */
        void clear();
    }

    /**
     * The current count for a licensed quota.
     *
     * <p>The SDK knows the ceilings but not how the things being counted are modelled, so the
     * product contributes counters — one per area, each answering only for the codes it owns. A
     * quota nothing answers for is not enforced, and that is said once at start rather than let
     * through silently.
     */
    public interface QuotaCounter {

        /**
         * The quota codes this counter answers for.
         *
         * <p>Declared rather than asked one at a time, so "what this deployment can count" is
         * one list, and both the guard and the vocabulary reported at activation read it here.
         *
         * @return the codes this counter answers for
         */
        List<String> countedQuotaCodes();

        /**
         * @param quotaCode a code this counter supports
         * @return the current count
         */
        long count(String quotaCode);

        /**
         * @param quotaCode the code to test
         * @return whether this counter answers for it
         */
        default boolean supports(String quotaCode) {
            return countedQuotaCodes().contains(quotaCode);
        }
    }

    /**
     * Every feature key this deployment actually gates on.
     *
     * <p>The keys are scattered across the product's gates, so nothing in the SDK can enumerate
     * them. What the list is for is reconciliation: the issuer sells modules by key and cannot
     * know which of them a given deployment can act on, and a key that was sold but is gated
     * nowhere earns a customer nothing.
     */
    public interface FeatureCatalogue {

        /**
         * @return the feature keys this deployment gates on
         */
        List<String> gatedFeatures();
    }

    /**
     * Which product this deployment is, and which release runs here.
     *
     * <p>This comes from code, never from configuration. A deployment that could edit its own
     * product code could accept a license issued for another product, and the issuer signs
     * every product with one key.
     */
    public interface ProductIdentity {

        /**
         * @return the product code, matching the code the issuer's catalogue carries
         */
        String productCode();

        /**
         * @return the running release, reported at activation and checked against the ceiling
         */
        String release();
    }

    /**
     * Whether a licensed feature is effectively active.
     *
     * <p>The license grants permission; an administrator grants activation. A billable add-on is
     * effectively active only when both say so. A product that models no such switch registers
     * nothing here and every licensed feature is active.
     */
    public interface FeatureActivationChecker {

        /**
         * @param feature the feature key
         * @return whether the feature is effectively active
         */
        boolean isEffectivelyActive(String feature);
    }

    /** The registration lifecycle events worth a record. */
    public enum LifecycleEvent {
        /** A seat was claimed. */
        ACTIVATED,
        /** A seat was handed back. */
        DEACTIVATED,
        /** A token was refreshed. */
        HEARTBEAT,
        /** The issuing server revoked this activation. */
        REVOKED
    }

    /**
     * Recording license events into the product's audit trail.
     *
     * <p>An implementation must not let a recording failure reach its caller. Judgement runs at
     * start and on a schedule, and a failed audit write may never change what a deployment
     * concludes about its license.
     */
    public interface AuditRecorder {

        /**
         * Records a change in status.
         *
         * <p>Only a transition is worth a row — judgement runs on a schedule, and recording
         * every pass buries the moment a deployment stopped being licensed under thousands of
         * rows saying it still was.
         *
         * @param previous the status before this judgement
         * @param current the status after it
         * @param licenseId the license the status belongs to, may be null
         */
        void recordStatusChange(LicenseStatus previous, LicenseStatus current, String licenseId);

        /**
         * Records a registration lifecycle event.
         *
         * @param event what happened
         * @param licenseId the license involved, may be null
         * @param detail a short human-readable detail, may be null
         */
        void recordLifecycle(LifecycleEvent event, String licenseId, String detail);

        /**
         * Records an operation refused because a licensed ceiling was reached.
         *
         * @param quotaCode the ceiling that refused the operation
         * @param current how many the deployment already holds
         * @param limit the licensed ceiling
         */
        void recordLimitReached(String quotaCode, long current, long limit);
    }

    /**
     * Where this deployment reaches its activation server.
     *
     * <p>Configuration alone cannot answer this. A deployment is installed before anyone decides
     * which server it belongs to — often by someone holding the address on a printed page and
     * with no way to edit a file on the host — so the address has to be settable while the
     * product runs and has to survive a restart. That makes it deployment state rather than
     * deployment configuration.
     */
    public interface ActivationServerDirectory {

        /**
         * @return the address to use, or empty to fall back to the configured one
         */
        Optional<String> serverUrl();
    }
}
