package dev.accesscore.license.sdk.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * How a token was signed.
 *
 * <p>Issuance uses Ed25519: a 64-byte signature and a 32-byte public key keep a hand-carried
 * token short and make embedding the verification key in a binary cost nothing. Verification
 * also reads RSA-4096 PSS, so a customer who has to keep the private key in a hardware module
 * can be served without touching a deployed verifier.
 */
public enum SignatureAlgorithm {

    /** Ed25519 over the payload bytes. */
    ED25519("Ed25519"),

    /** RSASSA-PSS with SHA-256, MGF1-SHA-256, and a 32-byte salt, over the payload bytes. */
    RSA_PSS_SHA256("RSA-PSS-SHA256");

    private final String wireName;

    SignatureAlgorithm(String wireName) {
        this.wireName = wireName;
    }

    /**
     * @return the name this algorithm carries on the wire
     */
    @JsonValue
    public String wireName() {
        return wireName;
    }

    /**
     * @param value the name as written in a payload
     * @return the algorithm, or null for one this SDK does not implement
     */
    @JsonCreator
    public static SignatureAlgorithm fromWireName(String value) {
        for (SignatureAlgorithm algorithm : values()) {
            if (algorithm.wireName.equals(value)) {
                return algorithm;
            }
        }
        return null;
    }
}
