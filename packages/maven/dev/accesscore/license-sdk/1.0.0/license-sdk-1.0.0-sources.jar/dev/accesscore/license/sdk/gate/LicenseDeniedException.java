package dev.accesscore.license.sdk.gate;

import dev.accesscore.license.sdk.model.LicenseModel.Denial;
import dev.accesscore.license.sdk.model.LicenseStatus;

/**
 * What a gate throws when it refuses a request.
 *
 * <p>It carries a key and its arguments rather than a sentence. The SDK does not know the
 * request locale, and a message the SDK wrote would need translating once per language it
 * binds; the host already has a message resolver and its own locales.
 *
 * <p>Every adapter turns this into that framework's response and decides nothing of its own —
 * the status code and the error code both come from here, which is why a refusal reads the
 * same whichever framework served it.
 */
public class LicenseDeniedException extends RuntimeException {

    private final transient LicenseStatus status;
    private final String errorCode;
    private final transient Denial denial;
    private final int httpStatus;

    /**
     * @param status the status behind the refusal
     * @param errorCode the code a client branches on
     * @param denial the message key and its arguments
     * @param httpStatus the status an adapter answers with
     */
    public LicenseDeniedException(LicenseStatus status, String errorCode, Denial denial,
                                  int httpStatus) {
        super(errorCode + ": " + denial.messageKey());
        this.status = status;
        this.errorCode = errorCode;
        this.denial = denial;
        this.httpStatus = httpStatus;
    }

    /**
     * @return the status behind the refusal
     */
    public LicenseStatus status() {
        return status;
    }

    /**
     * @return the code a client branches on; always begins with {@code LICENSE_}
     */
    public String errorCode() {
        return errorCode;
    }

    /**
     * @return the message key and its arguments
     */
    public Denial denial() {
        return denial;
    }

    /**
     * @return the status an adapter answers with
     */
    public int httpStatus() {
        return httpStatus;
    }
}
