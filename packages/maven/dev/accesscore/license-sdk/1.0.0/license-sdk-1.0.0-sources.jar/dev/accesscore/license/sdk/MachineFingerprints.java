package dev.accesscore.license.sdk;

import com.fasterxml.jackson.databind.JsonNode;
import dev.accesscore.license.sdk.ffi.AclicCore;

import java.util.List;
import java.util.Map;

/**
 * Hashing machine identifiers, and deciding whether they describe the machine a license names.
 *
 * <p>Reading a machine and calculating over what was read are separate: reading is platform
 * input and output, and this is a fixed output for a fixed input. The separation is what lets
 * the issuing side — which never runs on the machine a license binds to — apply the same
 * matching rule the deployment does when it decides which seat a request belongs to.
 */
public final class MachineFingerprints {

    /** What the comparison concluded. */
    public enum MatchOutcome {
        /** Enough of what the machine reports is in the license. */
        MATCH,
        /** The machine reports identifiers, but too few of them are in the license. */
        MISMATCH,
        /** Not one identifier could be read, so there is nothing to compare. */
        UNAVAILABLE
    }

    private final AclicCore core;

    /**
     * Uses the shared core.
     */
    public MachineFingerprints() {
        this(AclicCore.shared());
    }

    /**
     * @param core the core to call
     */
    public MachineFingerprints(AclicCore core) {
        this.core = core;
    }

    /**
     * The fingerprints of raw hardware identifiers.
     *
     * <p>Each is hashed on its own rather than folded into one digest, meaningless firmware
     * placeholders are dropped, and duplicates collapse.
     *
     * @param identifiers the raw identifiers
     * @return one fingerprint per identifier that means something
     */
    public List<String> hash(List<String> identifiers) {
        JsonNode answer = core.fingerprintCompute(
                Map.of("operation", "HASH", "identifiers", identifiers));
        return core.objectMapper().convertValue(answer.path("fingerprints"),
                core.objectMapper().getTypeFactory()
                        .constructCollectionType(List.class, String.class));
    }

    /**
     * Compares what a machine reports against what a license was stamped for.
     *
     * <p>The threshold is measured against what was collected, not against what was stamped:
     * an environment that reads fewer identifiers than the license names — a container without
     * its DMI mount — would otherwise have no way to pass at all.
     *
     * @param collected what the machine reports
     * @param stamped what the license names
     * @return whether they describe one machine
     */
    public MatchOutcome match(List<String> collected, List<String> stamped) {
        JsonNode answer = core.fingerprintCompute(
                Map.of("operation", "MATCH", "collected", collected, "stamped", stamped));
        return MatchOutcome.valueOf(answer.path("outcome").asText());
    }

    /**
     * @param collected what the machine reports
     * @param stamped what the license names
     * @return whether they describe one machine
     */
    public boolean matches(List<String> collected, List<String> stamped) {
        return match(collected, stamped) == MatchOutcome.MATCH;
    }
}
