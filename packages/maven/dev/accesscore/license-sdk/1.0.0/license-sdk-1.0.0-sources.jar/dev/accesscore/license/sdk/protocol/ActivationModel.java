package dev.accesscore.license.sdk.protocol;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import dev.accesscore.license.sdk.model.LicenseModel.KeyMaterial;
import dev.accesscore.license.sdk.model.LicenseModel.LicensePayload;
import dev.accesscore.license.sdk.model.SignatureAlgorithm;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * The activation conversation, as Java writes and reads it.
 *
 * <p>The core writes the request body and reads the answer; the host sends it. Handing the body
 * to the host as well would let four languages send four slightly different requests, and the
 * server would find out late and from one customer at a time.
 */
public final class ActivationModel {

    private ActivationModel() {
    }

    /** Which request is being made. */
    public enum ActivationOperation {
        /** Claim a seat and obtain a machine-bound token. */
        ACTIVATE,
        /** Refresh the token, which is how revocation, expiry, and contract changes arrive. */
        HEARTBEAT,
        /** Hand the seat back so another machine can take it. */
        DEACTIVATE
    }

    /**
     * Why an attempt did not succeed.
     *
     * <p>The reasons are held apart because they ask different things of a caller: a rejected
     * product key is an input error to show the operator, an exhausted seat needs a release
     * somewhere else, and an unreachable server is a passing condition that must not discard a
     * working license.
     */
    public enum ActivationError {
        /** No activation server is configured, so nothing can be attempted. */
        NOT_CONFIGURED,
        /** Not one machine identifier could be read. */
        FINGERPRINT_UNAVAILABLE,
        /** The server does not know this product key. */
        UNKNOWN_PRODUCT_KEY,
        /** Every seat on this license is already held by another machine. */
        SEAT_EXHAUSTED,
        /** The contract behind this license is suspended. */
        SUSPENDED,
        /** The key sells a different product than the one running here. */
        PRODUCT_MISMATCH,
        /** The release running here is above what the contract entitles. */
        RELEASE_NOT_ENTITLED,
        /** This activation has been revoked. */
        REVOKED,
        /** The server could not be reached. */
        SERVER_UNREACHABLE,
        /** The server answered with an error. */
        SERVER_ERROR,
        /** The answer was not a well-formed activation response. */
        INVALID_RESPONSE,
        /** The returned token does not echo the nonce that was sent. */
        NONCE_MISMATCH,
        /** The returned token is not bound to this machine. */
        FINGERPRINT_MISMATCH,
        /** The returned token is not signed by a key this deployment carries. */
        INVALID_SIGNATURE,
        /** No activation exists here, so there is nothing to refresh or release. */
        NOT_ACTIVATED,
        /** A usable license under another key is already registered here. */
        ALREADY_REGISTERED;

        /**
         * The message key describing this reason to the operator.
         *
         * <p>The four ways a token is refused after it arrives — a wrong signing key, a license
         * bound to another machine, a replayed answer, and an unreadable one — are named apart
         * on purpose. They need four different actions from an operator, and one shared "could
         * not be verified" line leaves every one of them undiagnosable.
         *
         * @return the key the host resolves against the request locale
         */
        public String messageKey() {
            return switch (this) {
                case NOT_CONFIGURED -> "error.license.activationServerNotConfigured";
                case FINGERPRINT_UNAVAILABLE -> "error.license.fingerprintUnavailable";
                case UNKNOWN_PRODUCT_KEY -> "error.license.unknownProductKey";
                case SEAT_EXHAUSTED -> "error.license.seatExhausted";
                case SUSPENDED -> "error.license.contractSuspended";
                case PRODUCT_MISMATCH -> "error.license.productMismatch";
                case RELEASE_NOT_ENTITLED -> "error.license.releaseNotEntitled";
                case REVOKED -> "error.license.revoked";
                case SERVER_UNREACHABLE -> "error.license.serverUnreachable";
                case SERVER_ERROR -> "error.license.serverError";
                case INVALID_RESPONSE -> "error.license.invalidResponse";
                case NONCE_MISMATCH -> "error.license.nonceMismatch";
                case FINGERPRINT_MISMATCH -> "error.license.fingerprintMismatch";
                case INVALID_SIGNATURE -> "error.license.invalidSignature";
                case NOT_ACTIVATED -> "error.license.notActivated";
                case ALREADY_REGISTERED -> "error.license.alreadyRegistered";
            };
        }
    }

    /**
     * Everything a request is built from.
     *
     * @param operation which request to build
     * @param productKey the customer-facing key; required to activate
     * @param activationId the activation to refresh or release
     * @param activationSecret the secret later requests are signed with
     * @param productCode which product this deployment is
     * @param productRelease which release runs here
     * @param machineFingerprints what this machine reports about itself
     * @param instanceId this deployment's stable identifier
     * @param nonce a value the server echoes; drawn by the core when null
     * @param requestedAt when the host created the request
     * @param knownFeatures the feature keys this deployment gates on
     * @param knownQuotas the quota codes this deployment can count
     * @param usage what this deployment currently holds, per quota code
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record RequestInput(
            ActivationOperation operation,
            String productKey,
            String activationId,
            String activationSecret,
            String productCode,
            String productRelease,
            List<String> machineFingerprints,
            String instanceId,
            String nonce,
            Instant requestedAt,
            List<String> knownFeatures,
            List<String> knownQuotas,
            Map<String, Long> usage
    ) {
    }

    /**
     * A request ready for the host to send.
     *
     * @param method the HTTP method
     * @param path the path under the server's address
     * @param body the body exactly as it must be sent; the signature covers these bytes
     * @param headers the headers to send, the signature among them when the request is signed
     * @param nonce the nonce stamped into this request, which the answer has to echo
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record PreparedRequest(
            String method,
            String path,
            String body,
            Map<String, String> headers,
            String nonce
    ) {
    }

    /**
     * Everything reading an answer needs.
     *
     * @param operation which request this answers
     * @param status the HTTP status the server answered with
     * @param body the response body, as received
     * @param nonce the nonce that was sent
     * @param keys the verification keys this deployment carries
     * @param allowedAlgorithms the algorithms it accepts; null means all the SDK implements
     * @param collectedFingerprints what this machine reports about itself
     * @param reachable whether the server was reachable at all
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record ResponseInput(
            ActivationOperation operation,
            int status,
            String body,
            String nonce,
            List<KeyMaterial> keys,
            List<SignatureAlgorithm> allowedAlgorithms,
            List<String> collectedFingerprints,
            Boolean reachable
    ) {
    }

    /**
     * What a successful attempt returned.
     *
     * @param licenseToken the signed token
     * @param activationId the server-side activation identifier
     * @param activationSecret the secret later requests are signed with; first activation only
     * @param payload the payload, already checked against this machine and this nonce
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ActivationSuccess(
            String licenseToken,
            String activationId,
            String activationSecret,
            LicensePayload payload
    ) {
    }

    /**
     * The result of an activation, heartbeat, or release attempt.
     *
     * @param success whether the attempt succeeded
     * @param error why it did not
     * @param messageKey the message key for the reason
     * @param result what the attempt returned
     * @param detail a line for logs and operator-facing errors
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ActivationOutcome(
            boolean success,
            ActivationError error,
            String messageKey,
            ActivationSuccess result,
            String detail
    ) {

        /**
         * @param error the reason
         * @param detail a message for logs and operator-facing errors
         * @return a failed outcome carrying that reason and its message key
         */
        public static ActivationOutcome failure(ActivationError error, String detail) {
            return new ActivationOutcome(false, error, error.messageKey(), null, detail);
        }

        /**
         * @return a successful outcome that carries nothing back, as a release does
         */
        public static ActivationOutcome released() {
            return new ActivationOutcome(true, null, null, null, "");
        }

        /**
         * @param result what the attempt returned
         * @return a successful outcome
         */
        public static ActivationOutcome success(ActivationSuccess result) {
            return new ActivationOutcome(true, null, null, result, "");
        }

        /**
         * @return whether the attempt succeeded
         */
        public boolean isSuccess() {
            return success;
        }
    }
}
