package dev.accesscore.license.sdk;

import dev.accesscore.license.sdk.ffi.AclicCore;
import dev.accesscore.license.sdk.gate.LicenseGate;
import dev.accesscore.license.sdk.model.LicenseModel.CollectedIdentifiers;
import dev.accesscore.license.sdk.model.LicenseModel.EvaluationRequest;
import dev.accesscore.license.sdk.model.LicenseModel.EvaluationResponse;
import dev.accesscore.license.sdk.model.LicenseModel.KeyMaterial;
import dev.accesscore.license.sdk.model.LicenseModel.RegistrationRecord;
import dev.accesscore.license.sdk.model.LicenseStatus;
import dev.accesscore.license.sdk.protocol.ActivationModel.ActivationOperation;
import dev.accesscore.license.sdk.protocol.ActivationModel.ActivationOutcome;
import dev.accesscore.license.sdk.protocol.ActivationModel.PreparedRequest;
import dev.accesscore.license.sdk.protocol.ActivationModel.RequestInput;
import dev.accesscore.license.sdk.protocol.ActivationModel.ResponseInput;
import dev.accesscore.license.sdk.spi.LicenseSpi.ActivationServerDirectory;
import dev.accesscore.license.sdk.spi.LicenseSpi.AuditRecorder;
import dev.accesscore.license.sdk.spi.LicenseSpi.FeatureCatalogue;
import dev.accesscore.license.sdk.spi.LicenseSpi.LicenseStore;
import dev.accesscore.license.sdk.spi.LicenseSpi.LifecycleEvent;
import dev.accesscore.license.sdk.spi.LicenseSpi.ProductIdentity;
import dev.accesscore.license.sdk.spi.LicenseSpi.QuotaCounter;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * What ties the host's interfaces to the core.
 *
 * <p>It reads the store, asks the machine what it is, calls the core, and hands the answer to
 * the gate. It is the only class in the binding that touches both sides.
 *
 * <p>Enforcement is unconditional. No setting turns it off, so an unlicensed deployment is one
 * with no usable features rather than one with a bypass flag set. Development runs the same
 * path with a development-channel license.
 */
public class LicenseManager {

    private final AclicCore core;
    private final LicenseGate gate;
    private final LicenseStore store;
    private final ProductIdentity identity;
    private final List<KeyMaterial> keys;
    private final FeatureCatalogue catalogue;
    private final List<QuotaCounter> counters;
    private final AuditRecorder audit;
    private final ActivationServerDirectory directory;
    private final String configuredServerUrl;
    private final String instanceId;

    private LicenseManager(Builder builder) {
        this.core = builder.core != null ? builder.core : AclicCore.shared();
        this.gate = builder.gate != null ? builder.gate : new LicenseGate();
        this.store = builder.store;
        this.identity = builder.identity;
        this.keys = List.copyOf(builder.keys);
        this.catalogue = builder.catalogue;
        this.counters = List.copyOf(builder.counters);
        this.audit = builder.audit;
        this.directory = builder.directory;
        this.configuredServerUrl = normalizeServerUrl(builder.configuredServerUrl);
        this.instanceId = builder.instanceId;
    }

    /**
     * @param store where the registration is persisted
     * @param identity which product this deployment is
     * @param keys the verification keys this build carries
     * @return a builder over the required interfaces
     */
    public static Builder builder(LicenseStore store, ProductIdentity identity,
                                  List<KeyMaterial> keys) {
        return new Builder(store, identity, keys);
    }

    /**
     * @return the gate every request-time check goes through
     */
    public LicenseGate gate() {
        return gate;
    }

    /**
     * @return the core, for a caller that needs an operation this class does not wrap
     */
    public AclicCore core() {
        return core;
    }

    /**
     * Judges the stored registration and publishes the result to the gate.
     *
     * @param now the current instant, which the host's clock supplies because the core has none
     * @param integrityOk whether the host's own binary hashed to what it expected
     * @return the judgement
     */
    public EvaluationResponse verify(Instant now, boolean integrityOk) {
        LicenseStatus previous = gate.status();
        CollectedIdentifiers collected = fingerprint();

        EvaluationRequest request = new EvaluationRequest(
                null,
                keys,
                null,
                store.load().map(RegistrationRecord::toStoredRecord).orElse(null),
                now,
                integrityOk,
                identity.productCode(),
                identity.release(),
                collected.fingerprintsOrEmpty());

        EvaluationResponse response = core.evaluate(request, EvaluationResponse.class);
        persistWatermark(response);
        gate.refresh(response);
        recordTransition(previous, response);
        return response;
    }

    /**
     * Replaces the stored registration and judges it, so a caller that obtains a new token
     * never has to reason about runtime state itself.
     *
     * @param record the registration to persist
     * @param now the current instant
     * @param integrityOk whether the binary hashed to what the host expected
     * @return the judgement
     */
    public EvaluationResponse apply(RegistrationRecord record, Instant now, boolean integrityOk) {
        store.save(record);
        return verify(now, integrityOk);
    }

    /**
     * Records that the issuing server revoked this activation and judges again.
     *
     * <p>The stamp is persisted so the denial outlives a restart.
     *
     * @param now the current instant
     * @param integrityOk whether the binary hashed to what the host expected
     * @return the judgement
     */
    public EvaluationResponse markRevoked(Instant now, boolean integrityOk) {
        RegistrationRecord record = store.load().orElse(RegistrationRecord.ofToken(null));
        store.save(record.withRevocation(now));
        recordLifecycle(LifecycleEvent.REVOKED, null, null);
        return verify(now, integrityOk);
    }

    /**
     * Discards the registration, returning the deployment to its unregistered state.
     *
     * @param now the current instant
     * @param integrityOk whether the binary hashed to what the host expected
     * @return the judgement
     */
    public EvaluationResponse clearRegistration(Instant now, boolean integrityOk) {
        store.clear();
        return verify(now, integrityOk);
    }

    /**
     * @return the persisted registration, or empty when nothing is registered
     */
    public Optional<RegistrationRecord> currentRecord() {
        return store.load();
    }

    /**
     * @return what this machine reports about itself
     */
    public CollectedIdentifiers fingerprint() {
        return core.fingerprint(CollectedIdentifiers.class);
    }

    /**
     * Writes the activation request the host sends.
     *
     * @param productKey the customer-facing key an operator typed
     * @param now the instant the host created the request
     * @return the request, ready to send
     */
    public PreparedRequest activationRequest(String productKey, Instant now) {
        return core.activationRequest(new RequestInput(
                ActivationOperation.ACTIVATE,
                productKey,
                null,
                null,
                identity.productCode(),
                identity.release(),
                fingerprint().fingerprintsOrEmpty(),
                instanceId,
                null,
                now,
                gatedFeatures(),
                countedQuotas(),
                Map.of()), PreparedRequest.class);
    }

    /**
     * Writes the heartbeat request the host sends.
     *
     * @param now the instant the host created the request
     * @return the request, ready to send
     */
    public PreparedRequest heartbeatRequest(Instant now) {
        RegistrationRecord record = store.load().orElse(RegistrationRecord.ofToken(null));
        return core.activationRequest(new RequestInput(
                ActivationOperation.HEARTBEAT,
                null,
                record.activationId(),
                record.activationSecret(),
                identity.productCode(),
                identity.release(),
                fingerprint().fingerprintsOrEmpty(),
                record.instanceId() != null ? record.instanceId() : instanceId,
                null,
                now,
                gatedFeatures(),
                countedQuotas(),
                usage()), PreparedRequest.class);
    }

    /**
     * Writes the release request the host sends, handing the seat back.
     *
     * @param now the instant the host created the request
     * @return the request, ready to send
     */
    public PreparedRequest deactivationRequest(Instant now) {
        RegistrationRecord record = store.load().orElse(RegistrationRecord.ofToken(null));
        return core.activationRequest(new RequestInput(
                ActivationOperation.DEACTIVATE,
                null,
                record.activationId(),
                record.activationSecret(),
                identity.productCode(),
                identity.release(),
                fingerprint().fingerprintsOrEmpty(),
                record.instanceId() != null ? record.instanceId() : instanceId,
                null,
                now,
                List.of(),
                List.of(),
                Map.of()), PreparedRequest.class);
    }

    /**
     * Reads the answer the server gave.
     *
     * <p>The token is checked against this deployment's key, this deployment's machine, and the
     * nonce it just sent, before the host is told to store anything. Storing first and judging
     * at the next start would leave a deployment holding a token it will refuse.
     *
     * @param operation which request this answers
     * @param status the HTTP status the server answered with
     * @param body the response body, as received
     * @param nonce the nonce that was sent
     * @param reachable whether the server was reachable at all
     * @return the outcome
     */
    public ActivationOutcome interpret(ActivationOperation operation, int status, String body,
                                       String nonce, boolean reachable) {
        return core.activationResponse(new ResponseInput(
                operation,
                status,
                body,
                nonce,
                keys,
                null,
                fingerprint().fingerprintsOrEmpty(),
                reachable), ActivationOutcome.class);
    }

    /**
     * The address to call, read per request rather than fixed at start.
     *
     * <p>An operator who registers a server during installation expects the next activation to
     * go there, not after a restart they have no way to perform.
     *
     * @return the registered address, or the configured one when none is registered
     */
    public String serverUrl() {
        if (directory == null) {
            return configuredServerUrl;
        }
        return directory.serverUrl()
                .map(LicenseManager::normalizeServerUrl)
                .filter(url -> !url.isEmpty())
                .orElse(configuredServerUrl);
    }

    /**
     * Records a registration lifecycle event, if the host contributed somewhere to record it.
     *
     * @param event what happened
     * @param licenseId the license involved, may be null
     * @param detail a short human-readable detail, may be null
     */
    public void recordLifecycle(LifecycleEvent event, String licenseId, String detail) {
        if (audit != null) {
            audit.recordLifecycle(event, licenseId, detail);
        }
    }

    /**
     * @return the feature keys this deployment gates on
     */
    public List<String> gatedFeatures() {
        return catalogue == null ? List.of() : catalogue.gatedFeatures();
    }

    /**
     * @return the quota codes this deployment can count
     */
    public List<String> countedQuotas() {
        List<String> codes = new ArrayList<>();
        for (QuotaCounter counter : counters) {
            codes.addAll(counter.countedQuotaCodes());
        }
        return codes;
    }

    /**
     * @return what this deployment currently holds, per quota code
     */
    public Map<String, Long> usage() {
        Map<String, Long> usage = new LinkedHashMap<>();
        for (QuotaCounter counter : counters) {
            for (String code : counter.countedQuotaCodes()) {
                usage.put(code, counter.count(code));
            }
        }
        return usage;
    }

    /**
     * Checks an addition against the licensed ceiling, counting through the host's counters.
     *
     * @param quotaCode the ceiling to check
     * @throws dev.accesscore.license.sdk.gate.LicenseDeniedException when one more would pass it
     */
    public void checkQuota(String quotaCode) {
        long current = counters.stream()
                .filter(counter -> counter.supports(quotaCode))
                .mapToLong(counter -> counter.count(quotaCode))
                .findFirst()
                .orElse(0L);
        try {
            gate.checkQuota(quotaCode, current);
        } catch (dev.accesscore.license.sdk.gate.LicenseDeniedException e) {
            if (audit != null) {
                Long limit = gate.state().limitFor(quotaCode);
                audit.recordLimitReached(quotaCode, current, limit == null ? 0L : limit);
            }
            throw e;
        }
    }

    /**
     * Persists the watermark the judgement produced.
     *
     * @param response the judgement
     */
    private void persistWatermark(EvaluationResponse response) {
        if (response.nextWatermark() == null) {
            return;
        }
        Optional<RegistrationRecord> loaded = store.load();
        if (loaded.isEmpty()) {
            return;
        }
        RegistrationRecord record = loaded.get();
        if (response.nextWatermark().equals(record.verificationWatermark())) {
            return;
        }
        store.save(record.withWatermark(response.nextWatermark()));
    }

    /**
     * Records a status change, and only a change.
     *
     * @param previous the status before this judgement
     * @param response the judgement
     */
    private void recordTransition(LicenseStatus previous, EvaluationResponse response) {
        if (audit == null || previous == response.status()) {
            return;
        }
        audit.recordStatusChange(previous, response.status(),
                response.payload() != null ? response.payload().licenseId() : null);
    }

    /**
     * @param serverUrl an address as configured or registered
     * @return the address without trailing slashes, so two forms of one address compare equal
     */
    private static String normalizeServerUrl(String serverUrl) {
        if (serverUrl == null) {
            return "";
        }
        String url = serverUrl.trim();
        while (url.endsWith("/")) {
            url = url.substring(0, url.length() - 1);
        }
        return url;
    }

    /** Assembles a manager over the interfaces a product contributes. */
    public static final class Builder {

        private final LicenseStore store;
        private final ProductIdentity identity;
        private final List<KeyMaterial> keys;
        private AclicCore core;
        private LicenseGate gate;
        private FeatureCatalogue catalogue;
        private final List<QuotaCounter> counters = new ArrayList<>();
        private AuditRecorder audit;
        private ActivationServerDirectory directory;
        private String configuredServerUrl;
        private String instanceId;

        private Builder(LicenseStore store, ProductIdentity identity, List<KeyMaterial> keys) {
            this.store = store;
            this.identity = identity;
            this.keys = keys;
        }

        /**
         * @param value the core to call, for a test that loads its own
         * @return this builder
         */
        public Builder core(AclicCore value) {
            this.core = value;
            return this;
        }

        /**
         * @param value the gate every enforcement point reads
         * @return this builder
         */
        public Builder gate(LicenseGate value) {
            this.gate = value;
            return this;
        }

        /**
         * @param value the catalogue of feature keys this deployment gates on
         * @return this builder
         */
        public Builder catalogue(FeatureCatalogue value) {
            this.catalogue = value;
            return this;
        }

        /**
         * @param value a counter for one area's quota codes
         * @return this builder
         */
        public Builder counter(QuotaCounter value) {
            this.counters.add(value);
            return this;
        }

        /**
         * @param values counters for several areas
         * @return this builder
         */
        public Builder counters(List<QuotaCounter> values) {
            this.counters.addAll(values);
            return this;
        }

        /**
         * @param value where license events are recorded
         * @return this builder
         */
        public Builder audit(AuditRecorder value) {
            this.audit = value;
            return this;
        }

        /**
         * @param value where the activation server address is kept
         * @return this builder
         */
        public Builder directory(ActivationServerDirectory value) {
            this.directory = value;
            return this;
        }

        /**
         * @param value the configured activation server address
         * @return this builder
         */
        public Builder configuredServerUrl(String value) {
            this.configuredServerUrl = value;
            return this;
        }

        /**
         * @param value this deployment's stable identifier
         * @return this builder
         */
        public Builder instanceId(String value) {
            this.instanceId = value;
            return this;
        }

        /**
         * @return the assembled manager
         */
        public LicenseManager build() {
            return new LicenseManager(this);
        }
    }
}
