package dev.accesscore.license.sdk;

import dev.accesscore.license.sdk.ffi.AclicCore;
import dev.accesscore.license.sdk.model.LicenseModel.SignedToken;

import java.util.Map;

/**
 * What a key is, without holding the half that signs.
 *
 * <p>A deployment carries only the verification key its build was given, and still has to
 * report which key pair it accepts licenses from: an operator compares that value against the
 * one the issuing server logs for its signing key, and two different values mean every token
 * that server issues would be refused here as unverifiable.
 *
 * <p>Publishing the fingerprint discloses nothing. The public key already ships inside the
 * build, and a digest turns back into no key material at all.
 */
public final class LicenseKeys {

    private final AclicCore core;

    /**
     * Uses the shared core.
     */
    public LicenseKeys() {
        this(AclicCore.shared());
    }

    /**
     * @param core the core to call
     */
    public LicenseKeys(AclicCore core) {
        this.core = core;
    }

    /**
     * Reads a verification key.
     *
     * @param publicKeyPem the key, as an X.509 PEM document
     * @return its fingerprint and the algorithm it verifies
     */
    public SignedToken describe(String publicKeyPem) {
        return core.sign(Map.of("publicKey", publicKeyPem), SignedToken.class);
    }

    /**
     * @param publicKeyPem the key, as an X.509 PEM document
     * @return the fingerprint, rendered as {@code SHA256:<base64url>}
     */
    public String fingerprintOf(String publicKeyPem) {
        return describe(publicKeyPem).fingerprint();
    }
}
