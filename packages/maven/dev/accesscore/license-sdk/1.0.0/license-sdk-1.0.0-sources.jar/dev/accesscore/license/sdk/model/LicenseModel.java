package dev.accesscore.license.sdk.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * The shapes that cross the boundary, gathered so a reader sees the whole contract at once.
 *
 * <p>These have no Java behaviour of their own beyond what the payload itself decides. Every
 * judgement is the core's; what is here is the vocabulary a caller writes a request in and
 * reads an answer out of.
 *
 * <p>Unknown fields are ignored throughout. A deployment on an older SDK than the server that
 * signed its token has to keep reading what it already holds, and a field it does not know is
 * not a reason to refuse a license.
 */
public final class LicenseModel {

    private LicenseModel() {
    }

    /**
     * Everything one signed license says.
     *
     * @param schemaVersion the schema this payload is written in
     * @param alg how the token was signed, held as written so an unimplemented name still reads
     * @param kid which verification key checks it
     * @param licenseId the contract-level identifier
     * @param activationId the seat-level identifier, one per machine
     * @param customerId the customer identifier in the issuing ledger
     * @param customer the customer display name
     * @param channel which relaxations the verifier accepts
     * @param productCode which product this license is for
     * @param maxRelease the highest release entitled; null means no ceiling
     * @param tierLabel the commercial bundle name, shown but never enforced
     * @param issuedAt when the token was signed
     * @param activatedAt when the seat was activated
     * @param expiresAt when the license stops being valid
     * @param gracePeriodDays how long past expiry a production license stays usable
     * @param machineFingerprints the machines this token was stamped for
     * @param nonce the activation request's nonce, echoed so a replay is detectable
     * @param features the feature keys granted; free strings to this SDK
     * @param limits the ceiling per quota code; an absent code is unlimited and zero is zero
     * @param heartbeatRequired whether the deployment must refresh its token periodically
     * @param heartbeatIntervalDays how often a refresh is attempted
     * @param heartbeatToleranceDays how long a missed refresh is tolerated before denial
     * @param metadata free-form issuance detail; no gate reads it
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record LicensePayload(
            Integer schemaVersion,
            String alg,
            String kid,
            String licenseId,
            String activationId,
            String customerId,
            String customer,
            LicenseChannel channel,
            String productCode,
            String maxRelease,
            String tierLabel,
            Instant issuedAt,
            Instant activatedAt,
            Instant expiresAt,
            Integer gracePeriodDays,
            List<String> machineFingerprints,
            String nonce,
            List<String> features,
            Map<String, Long> limits,
            Boolean heartbeatRequired,
            Integer heartbeatIntervalDays,
            Integer heartbeatToleranceDays,
            Map<String, String> metadata
    ) {

        /** The fingerprint entry that matches any machine; accepted on the DEV channel only. */
        public static final String WILDCARD_FINGERPRINT = "*";

        /**
         * @param feature the feature key
         * @return whether this license grants it
         */
        public boolean hasFeature(String feature) {
            return features != null && features.contains(feature);
        }

        /**
         * The ceiling for a quota code.
         *
         * <p>Null is unlimited, and zero is zero. A license issued before a quota code existed
         * carries no entry for it, and that must not read as forbidding everything under it.
         *
         * @param quotaCode the quota to look up
         * @return the ceiling, or null when the code is unlimited
         */
        public Long limitFor(String quotaCode) {
            return limits == null ? null : limits.get(quotaCode);
        }

        /**
         * @return the channel, defaulting to production so a payload without one never gains
         *         the development relaxations
         */
        public LicenseChannel effectiveChannel() {
            return channel != null ? channel : LicenseChannel.PRODUCTION;
        }

        /**
         * @return whether this license is bound to any machine rather than to named ones
         */
        public boolean hasWildcardFingerprint() {
            return machineFingerprints != null
                    && machineFingerprints.contains(WILDCARD_FINGERPRINT);
        }

        /**
         * @return the instant past which the license is unusable, grace period included
         */
        public Instant graceExpiresAt() {
            if (expiresAt == null) {
                return null;
            }
            if (!effectiveChannel().allowsGracePeriod()) {
                return expiresAt;
            }
            return expiresAt.plus(Duration.ofDays(gracePeriodDays == null ? 0 : gracePeriodDays));
        }
    }

    /**
     * A message key with the values that fill its placeholders.
     *
     * <p>The core carries keys and arguments, never translated text: every language the SDK
     * binds has its own internationalization, and a core holding wording would grow a phrase
     * book each time a language is added.
     *
     * @param messageKey the key the host resolves against the request locale
     * @param arguments the placeholder values, in the order the message takes them
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Denial(String messageKey, List<Object> arguments) {

        /**
         * @return the arguments in the form a message resolver takes, null when there are none
         *         so the resolver skips formatting entirely
         */
        public Object[] argumentArray() {
            return arguments == null || arguments.isEmpty() ? null : arguments.toArray();
        }
    }

    /**
     * One verification key a deployment carries.
     *
     * @param kid the name a payload's {@code kid} matches
     * @param alg what the holder says the key is; advisory, since the algorithm that decides
     *        anything comes from the key material itself
     * @param publicKey the key, as an X.509 PEM document
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record KeyMaterial(String kid, String alg, String publicKey) {

        /**
         * @param kid the key name
         * @param publicKey the key material
         * @return a key that lets its own material decide its algorithm
         */
        public static KeyMaterial of(String kid, String publicKey) {
            return new KeyMaterial(kid, null, publicKey);
        }
    }

    /**
     * The part of a registration one judgement reads.
     *
     * @param licenseToken the signed token this deployment registered
     * @param verificationWatermark the latest instant a judgement succeeded at
     * @param lastHeartbeatAt the latest instant a heartbeat succeeded at
     * @param revokedAt when the issuing server reported this activation revoked
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record StoredRecord(
            String licenseToken,
            Instant verificationWatermark,
            Instant lastHeartbeatAt,
            Instant revokedAt
    ) {
    }

    /**
     * Everything one judgement is given.
     *
     * @param token a token to judge instead of the stored one
     * @param keys the verification keys this deployment carries
     * @param allowedAlgorithms the algorithms it accepts; null means all the SDK implements
     * @param storedRecord what the host has persisted
     * @param now the current instant, as the host's clock reports it
     * @param integrityOk whether the host's own binary hashed to what it expected
     * @param productCode which product this deployment is
     * @param productRelease which release runs here
     * @param collectedFingerprints what this machine reports about itself
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record EvaluationRequest(
            String token,
            List<KeyMaterial> keys,
            List<SignatureAlgorithm> allowedAlgorithms,
            StoredRecord storedRecord,
            Instant now,
            Boolean integrityOk,
            String productCode,
            String productRelease,
            List<String> collectedFingerprints
    ) {
    }

    /**
     * Everything one judgement returns.
     *
     * @param status what the judgement concluded
     * @param usable whether the deployment keeps operating
     * @param errorCode the code a client branches on
     * @param denial the message key and arguments explaining a refusal or a restriction
     * @param nextWatermark the watermark the host should persist
     * @param availableFeatures the feature keys the deployment may act on
     * @param limits the ceiling per quota code
     * @param graceExpiresAt when the license stops being usable, grace period included
     * @param heartbeatDeadline when a required heartbeat stops being tolerated
     * @param payload the payload the status was judged from
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record EvaluationResponse(
            LicenseStatus status,
            boolean usable,
            String errorCode,
            Denial denial,
            Instant nextWatermark,
            List<String> availableFeatures,
            Map<String, Long> limits,
            Instant graceExpiresAt,
            Instant heartbeatDeadline,
            LicensePayload payload
    ) {

        /**
         * @param feature the feature key
         * @return whether this judgement grants it
         */
        public boolean grants(String feature) {
            return availableFeatures != null && availableFeatures.contains(feature);
        }

        /**
         * @param quotaCode the quota to look up
         * @return the ceiling, or null when the code is unlimited
         */
        public Long limitFor(String quotaCode) {
            return limits == null ? null : limits.get(quotaCode);
        }

        /**
         * @return the features, never null
         */
        public List<String> featuresOrEmpty() {
            return availableFeatures == null ? List.of() : availableFeatures;
        }
    }

    /**
     * Everything a deployment persists about its registration.
     *
     * <p>Wider than what a judgement reads. The signed token carries the granted rights; the
     * rest is local state the activation client needs across restarts — the credentials that
     * authenticate a heartbeat or a release, the monotonic watermark that makes a rolled-back
     * clock detectable, and the revocation stamp that has to outlive a restart to mean anything.
     *
     * @param productKey the customer-facing key the activation was obtained with
     * @param licenseToken the signed token
     * @param activationId the server-side activation identifier
     * @param activationSecret the shared secret heartbeat and release requests are signed with
     * @param instanceId this deployment's stable identifier
     * @param verificationWatermark the latest instant a judgement succeeded at
     * @param lastHeartbeatAt the latest instant a heartbeat succeeded at
     * @param revokedAt when the issuing server reported this activation revoked
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record RegistrationRecord(
            String productKey,
            String licenseToken,
            String activationId,
            String activationSecret,
            String instanceId,
            Instant verificationWatermark,
            Instant lastHeartbeatAt,
            Instant revokedAt
    ) {

        /**
         * @param licenseToken the signed token
         * @return a record holding only a token, for a license provisioned as a file
         */
        public static RegistrationRecord ofToken(String licenseToken) {
            return new RegistrationRecord(null, licenseToken, null, null, null, null, null, null);
        }

        /**
         * @return the part of this record a judgement reads
         */
        public StoredRecord toStoredRecord() {
            return new StoredRecord(licenseToken, verificationWatermark, lastHeartbeatAt,
                    revokedAt);
        }

        /**
         * @param watermark the new watermark instant
         * @return a copy with the watermark replaced
         */
        public RegistrationRecord withWatermark(Instant watermark) {
            return new RegistrationRecord(productKey, licenseToken, activationId, activationSecret,
                    instanceId, watermark, lastHeartbeatAt, revokedAt);
        }

        /**
         * @param token the refreshed token
         * @param heartbeatAt when the heartbeat succeeded
         * @return a copy with the token and heartbeat instant replaced
         */
        public RegistrationRecord withHeartbeat(String token, Instant heartbeatAt) {
            return new RegistrationRecord(productKey, token, activationId, activationSecret,
                    instanceId, verificationWatermark, heartbeatAt, revokedAt);
        }

        /**
         * @param revokedAtInstant when the revocation was reported
         * @return a copy marked revoked, so the denial outlives a restart
         */
        public RegistrationRecord withRevocation(Instant revokedAtInstant) {
            return new RegistrationRecord(productKey, licenseToken, activationId, activationSecret,
                    instanceId, verificationWatermark, lastHeartbeatAt, revokedAtInstant);
        }

        /**
         * @return whether a signed token is present
         */
        public boolean hasToken() {
            return licenseToken != null && !licenseToken.isBlank();
        }

        /**
         * @return whether heartbeat and release requests can be authenticated
         */
        public boolean hasActivationCredentials() {
            return activationId != null && !activationId.isBlank()
                    && activationSecret != null && !activationSecret.isBlank();
        }
    }

    /**
     * What this machine reports about itself.
     *
     * @param fingerprints one per identifier that could be read and means something
     * @param sources which sources answered
     * @param unavailableSources which sources were consulted and gave nothing, so an operator
     *        knows what to mount
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CollectedIdentifiers(
            List<String> fingerprints,
            List<String> sources,
            List<String> unavailableSources
    ) {

        /**
         * @return whether this machine could be identified at all
         */
        public boolean isAvailable() {
            return fingerprints != null && !fingerprints.isEmpty();
        }

        /**
         * @return the fingerprints, never null
         */
        public List<String> fingerprintsOrEmpty() {
            return fingerprints == null ? List.of() : fingerprints;
        }
    }

    /**
     * A freshly generated key pair.
     *
     * @param algorithm the algorithm the pair signs and verifies with
     * @param privateKeyPem the signing half, as a PKCS#8 PEM document
     * @param publicKeyPem the verification half, as an X.509 PEM document
     * @param fingerprint the value an operator compares between the two halves
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record GeneratedKeyPair(
            SignatureAlgorithm algorithm,
            String privateKeyPem,
            String publicKeyPem,
            String fingerprint
    ) {
    }

    /**
     * What signing returns.
     *
     * @param token the token a deployment stores, null when only the key was asked about
     * @param fingerprint the fingerprint of the key pair
     * @param algorithm which algorithm the key signs with
     * @param publicKeyPem the verification half, which is what a deployment has to carry
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record SignedToken(String token, String fingerprint, SignatureAlgorithm algorithm,
                              String publicKeyPem) {
    }

    /**
     * What checking a signature returns.
     *
     * @param valid whether the signature checks out
     * @param algorithm which algorithm it was checked with
     * @param refusal why it was refused, when it was
     * @param payload the payload the token carries
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record SignatureCheck(
            boolean valid,
            SignatureAlgorithm algorithm,
            String refusal,
            LicensePayload payload
    ) {
    }
}
