package dev.accesscore.license.sdk.ffi;

import com.sun.jna.Library;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.PointerByReference;

/**
 * The C ABI, declared for JNA.
 *
 * <p>Every function takes a NUL-terminated UTF-8 request and writes its answer through an
 * out-parameter the caller frees with {@link #aclic_string_free}. A non-zero return means the
 * call produced no result, and the answer — when one was written — is an error document.
 *
 * <p>The names are the C names rather than Java ones on purpose: this interface is a
 * transcription of {@code include/aclic.h}, and a reader comparing the two should not have to
 * translate between them.
 */
public interface AclicLibrary extends Library {

    /** The call produced a result. */
    int ACLIC_OK = 0;

    /** A required pointer was null. */
    int ACLIC_NULL_ARGUMENT = -1;

    /** A request was not valid UTF-8. */
    int ACLIC_INVALID_UTF8 = -2;

    /** The operation produced no result; the answer is an error document. */
    int ACLIC_OPERATION_FAILED = -3;

    /** The core panicked. */
    int ACLIC_PANIC = -4;

    @SuppressWarnings("MethodName")
    int aclic_evaluate(String reqJson, PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_sign(String reqJson, PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_verify_signature(String reqJson, PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_fingerprint(PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_fingerprint_compute(String reqJson, PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_activation_request(String reqJson, PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_activation_response(String resJson, PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_generate_keypair(String reqJson, PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_product_key(String reqJson, PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_release(String reqJson, PointerByReference outJson);

    @SuppressWarnings("MethodName")
    int aclic_schema_version();

    @SuppressWarnings("MethodName")
    Pointer aclic_version();

    @SuppressWarnings("MethodName")
    void aclic_string_free(Pointer s);
}
