package dev.accesscore.license.sdk.adapter;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a class or a method as needing a licensed feature.
 *
 * <p>The value is a key from the product's own feature-key constants. Use the constant rather
 * than a literal: a typo in a literal silently opens the gate.
 *
 * <pre>{@code
 * @RestController
 * @RequiresFeature(PacsFeatures.ATTENDANCE)
 * public class AttendanceRecordRestController {
 *     // Every endpoint here needs the ATTENDANCE feature
 * }
 * }</pre>
 *
 * <p>Which framework enforces it is the adapter's business. The annotation itself says only
 * what is required.
 */
@Documented
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface RequiresFeature {

    /**
     * @return the feature key the license must grant
     */
    String value();
}
