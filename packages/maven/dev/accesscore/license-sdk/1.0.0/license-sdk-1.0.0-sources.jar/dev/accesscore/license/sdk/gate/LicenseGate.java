package dev.accesscore.license.sdk.gate;

import dev.accesscore.license.sdk.model.LicenseModel.Denial;
import dev.accesscore.license.sdk.model.LicenseModel.EvaluationResponse;
import dev.accesscore.license.sdk.model.LicenseStatus;
import dev.accesscore.license.sdk.spi.LicenseSpi.FeatureActivationChecker;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * The neutral gate.
 *
 * <p>Four operations, the same four in every language the SDK binds:
 *
 * <pre>{@code
 * gate.state()                     the cached judgement
 * gate.requireFeature(key)         refuse when the license does not grant it
 * gate.checkQuota(code, current)   refuse when the ceiling is passed
 * gate.refresh(evaluation)         replace the cache with a fresh judgement
 * }</pre>
 *
 * <p>The binding holds the judgement; the host decides when to refresh it — at start, after a
 * successful activation, after a successful heartbeat, and on whatever schedule it keeps. The
 * gate that runs on every request reads this cache and never calls the core, which is why a
 * JSON boundary costs nothing at request time.
 *
 * <p>The cache is an {@link AtomicReference}: every enforcement point in the application reads
 * one instance, and a judgement is published whole rather than field by field.
 */
public class LicenseGate {

    /** The refusal an unlicensed or unentitled request gets. */
    public static final int FORBIDDEN = 403;

    /** The code a request refused for a feature the license does not grant carries. */
    public static final String FEATURE_NOT_LICENSED = "LICENSE_FEATURE_NOT_LICENSED";

    /** The code a request refused for a feature an administrator switched off carries. */
    public static final String FEATURE_NOT_ACTIVATED = "LICENSE_FEATURE_NOT_ACTIVATED";

    /** The code a request refused for passing a licensed ceiling carries. */
    public static final String QUOTA_EXCEEDED = "LICENSE_QUOTA_EXCEEDED";

    private final AtomicReference<EvaluationResponse> current;
    private final FeatureActivationChecker activationChecker;

    /**
     * A gate that has judged nothing yet.
     */
    public LicenseGate() {
        this(null);
    }

    /**
     * A gate that also consults whether an administrator switched a feature on.
     *
     * @param activationChecker where activation is decided, may be null
     */
    public LicenseGate(FeatureActivationChecker activationChecker) {
        this.activationChecker = activationChecker;
        this.current = new AtomicReference<>(unknown());
    }

    /**
     * @return the cached judgement
     */
    public EvaluationResponse state() {
        return current.get();
    }

    /**
     * Replaces the cache with a fresh judgement.
     *
     * @param evaluation what the core concluded
     */
    public void refresh(EvaluationResponse evaluation) {
        current.set(evaluation == null ? unknown() : evaluation);
    }

    /**
     * @return what the judgement concluded
     */
    public LicenseStatus status() {
        return current.get().status();
    }

    /**
     * @return whether the deployment keeps operating
     */
    public boolean isUsable() {
        return current.get().usable();
    }

    /**
     * Refuses when the deployment is not licensed to serve at all.
     *
     * @throws LicenseDeniedException when it is not
     */
    public void requireUsable() {
        EvaluationResponse evaluation = current.get();
        if (evaluation.usable()) {
            return;
        }
        throw new LicenseDeniedException(evaluation.status(), evaluation.errorCode(),
                denialOf(evaluation), FORBIDDEN);
    }

    /**
     * Refuses when the license does not grant a feature, or an administrator has not switched
     * it on.
     *
     * @param feature the feature key
     * @throws LicenseDeniedException when the feature is unavailable
     */
    public void requireFeature(String feature) {
        requireUsable();

        EvaluationResponse evaluation = current.get();
        if (!evaluation.grants(feature)) {
            throw new LicenseDeniedException(evaluation.status(), FEATURE_NOT_LICENSED,
                    new Denial("error.license.featureNotLicensed", List.of(feature)), FORBIDDEN);
        }
        if (!isActivated(feature)) {
            throw new LicenseDeniedException(evaluation.status(), FEATURE_NOT_ACTIVATED,
                    new Denial("error.license.featureNotActivated", List.of(feature)), FORBIDDEN);
        }
    }

    /**
     * Refuses when taking one more of something would pass its ceiling.
     *
     * <p>The comparison is against the count after the addition, so a deployment holding exactly
     * its ceiling is refused the next one rather than the one it already has.
     *
     * @param quotaCode the ceiling to check
     * @param current the count the deployment already holds
     * @throws LicenseDeniedException when one more would pass the ceiling
     */
    public void checkQuota(String quotaCode, long current) {
        requireUsable();

        EvaluationResponse evaluation = this.current.get();
        Long limit = evaluation.limitFor(quotaCode);
        if (limit == null) {
            return;
        }
        if (current + 1 <= limit) {
            return;
        }
        throw new LicenseDeniedException(evaluation.status(), QUOTA_EXCEEDED,
                new Denial("error.license.quotaExceeded", List.of(quotaCode, limit)), FORBIDDEN);
    }

    /**
     * @param feature the feature key
     * @return whether the license grants it and it is switched on
     */
    public boolean isAllowed(String feature) {
        EvaluationResponse evaluation = current.get();
        return evaluation.grants(feature) && isActivated(feature);
    }

    /**
     * @param feature the feature key
     * @return whether the license grants it, ignoring activation
     */
    public boolean isLicensed(String feature) {
        return current.get().grants(feature);
    }

    /**
     * @param feature the feature key
     * @return whether an administrator has switched it on
     */
    public boolean isActivated(String feature) {
        return activationChecker == null || activationChecker.isEffectivelyActive(feature);
    }

    /**
     * The features a client may act on: granted by the license and switched on.
     *
     * <p>A client gates its navigation on this list, so it has to agree with the server-side
     * gates — which it does, because both read it from here.
     *
     * @return the effectively available feature keys
     */
    public List<String> effectiveFeatures() {
        return current.get().featuresOrEmpty().stream().filter(this::isActivated).toList();
    }

    /**
     * @param evaluation the judgement
     * @return its denial, falling back to the general line when it carries none
     */
    private static Denial denialOf(EvaluationResponse evaluation) {
        return evaluation.denial() != null
                ? evaluation.denial()
                : new Denial("error.license.notValid", List.of());
    }

    /**
     * @return the state a deployment starts in, before anything has been judged
     */
    private static EvaluationResponse unknown() {
        return new EvaluationResponse(LicenseStatus.NOT_ACTIVATED, false,
                LicenseStatus.NOT_ACTIVATED.errorCode(),
                new Denial("error.license.notActivated", List.of()),
                null, List.of(), java.util.Map.of(), null, null, null);
    }
}
