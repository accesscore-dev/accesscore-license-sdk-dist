package dev.accesscore.license.sdk.adapter.spring;

import com.fasterxml.jackson.databind.ObjectMapper;
import dev.accesscore.license.sdk.adapter.DenialBody;
import dev.accesscore.license.sdk.gate.LicenseDeniedException;
import dev.accesscore.license.sdk.gate.LicenseGate;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Closes a Spring MVC deployment while its license does not let it serve.
 *
 * <p>Which paths stay open is the product's decision, not the SDK's: a deployment has to reach
 * its own license screen and its own activation endpoints in order to stop being unlicensed, and
 * only the product knows where those are. The filter takes the list rather than carrying one.
 *
 * <p>It decides nothing else. The status code, the error code, and the message key all come
 * from what the gate answered.
 */
public class LicenseEnforcementFilter extends OncePerRequestFilter {

    private final LicenseGate gate;
    private final List<String> openPatterns;
    private final ObjectMapper objectMapper;
    private final AntPathMatcher matcher = new AntPathMatcher();

    /**
     * @param gate the gate every enforcement point reads
     * @param openPatterns the paths that stay reachable while the deployment is unlicensed,
     *        as Ant patterns
     * @param objectMapper how the refusal body is written
     */
    public LicenseEnforcementFilter(LicenseGate gate, List<String> openPatterns,
                                    ObjectMapper objectMapper) {
        this.gate = gate;
        this.openPatterns = List.copyOf(openPatterns);
        this.objectMapper = objectMapper;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        if (isOpen(request)) {
            chain.doFilter(request, response);
            return;
        }

        try {
            gate.requireUsable();
        } catch (LicenseDeniedException denied) {
            write(response, denied);
            return;
        }
        chain.doFilter(request, response);
    }

    /**
     * @param request the request being served
     * @return whether it reaches a path that stays open while unlicensed
     */
    private boolean isOpen(HttpServletRequest request) {
        String path = request.getRequestURI();
        String context = request.getContextPath();
        if (context != null && !context.isEmpty() && path.startsWith(context)) {
            path = path.substring(context.length());
        }
        for (String pattern : openPatterns) {
            if (matcher.match(pattern, path)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param response the response to write the refusal to
     * @param denied what the gate refused
     */
    private void write(HttpServletResponse response, LicenseDeniedException denied)
            throws IOException {
        response.setStatus(denied.httpStatus());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        objectMapper.writeValue(response.getWriter(), DenialBody.of(denied).asMap());
    }
}
