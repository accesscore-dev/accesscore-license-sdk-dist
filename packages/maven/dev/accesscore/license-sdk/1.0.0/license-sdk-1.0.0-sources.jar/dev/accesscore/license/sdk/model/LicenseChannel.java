package dev.accesscore.license.sdk.model;

/**
 * The distribution channel a license was issued for.
 *
 * <p>The channel decides which relaxations the verifier accepts. A wildcard machine fingerprint
 * and the absence of a grace period only make sense for development, so both are tied to
 * {@link #DEV} rather than to a setting a customer could change.
 */
public enum LicenseChannel {

    /** Customer deployment: machine-bound, grace period applies, heartbeat may be required. */
    PRODUCTION,

    /** Development and continuous integration: wildcard fingerprint allowed, no grace period. */
    DEV;

    /**
     * @return whether this channel accepts a wildcard machine fingerprint
     */
    public boolean allowsWildcardFingerprint() {
        return this == DEV;
    }

    /**
     * @return whether this channel grants a grace period after expiry
     */
    public boolean allowsGracePeriod() {
        return this == PRODUCTION;
    }
}
