package dev.accesscore.license.sdk.issuing;

import dev.accesscore.license.sdk.model.LicenseChannel;
import dev.accesscore.license.sdk.model.LicenseModel.LicensePayload;
import dev.accesscore.license.sdk.model.SignatureAlgorithm;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * What the issuing side decides about a license, before it becomes a signed payload.
 *
 * <p>Separating the decision from the payload keeps the machine binding explicit: an issuance
 * starts without fingerprints and gets them from the activation it is being issued for, which
 * is what makes a token useless on any other machine.
 *
 * <p>The key facts — which key signs, and with which algorithm — are not here. They belong to
 * the key the issuer holds, not to the contract, and they arrive when the issuance is turned
 * into a payload.
 *
 * @param licenseId the contract-level identifier
 * @param activationId the seat-level identifier, one per machine
 * @param customerId the customer identifier in the ledger
 * @param customer the customer display name
 * @param channel PRODUCTION for customers, DEV for development and continuous integration
 * @param productCode which product the license is for, matched by the deployment
 * @param maxRelease the highest release entitled, null for no ceiling
 * @param tierLabel the commercial bundle name, shown but never enforced
 * @param expiresAt when the license stops being valid
 * @param gracePeriodDays how long past expiry a production license stays usable
 * @param machineFingerprints the machines to bind to, or a lone {@code *} on the DEV channel
 * @param nonce the activation request's nonce, echoed so a replay is detectable
 * @param features the feature keys granted
 * @param limits the ceiling per quota code; a code left out is unlimited and zero is zero
 * @param heartbeatRequired whether the deployment must refresh its token periodically
 * @param heartbeatIntervalDays how often a refresh is attempted
 * @param heartbeatToleranceDays how long a missed refresh is tolerated before denial
 */
public record LicenseIssuance(
        String licenseId,
        String activationId,
        String customerId,
        String customer,
        LicenseChannel channel,
        String productCode,
        String maxRelease,
        String tierLabel,
        Instant expiresAt,
        int gracePeriodDays,
        List<String> machineFingerprints,
        String nonce,
        List<String> features,
        Map<String, Long> limits,
        boolean heartbeatRequired,
        int heartbeatIntervalDays,
        int heartbeatToleranceDays
) {

    /** What the payload records as its issuer, for an operator reading a token. */
    private static final String ISSUER = "AccessCORE";

    /**
     * Stamps this issuance with the machines and nonce of the activation it is being issued
     * for. This is the step that turns a contract into a machine-bound license.
     *
     * @param binding the activation request being served
     * @return the issuance bound to that request
     */
    public LicenseIssuance boundTo(ActivationBinding binding) {
        return new LicenseIssuance(licenseId, activationId, customerId, customer, channel,
                productCode, maxRelease, tierLabel, expiresAt, gracePeriodDays,
                binding.machineFingerprints(), binding.nonce(), features, limits,
                heartbeatRequired, heartbeatIntervalDays, heartbeatToleranceDays);
    }

    /**
     * Builds the payload to sign.
     *
     * @param now the issuance instant, recorded as both issue and activation time
     * @param keyId which verification key checks the token
     * @param algorithm how it is signed
     * @param schemaVersion the schema this build writes, read from the core
     * @return the payload
     */
    public LicensePayload toPayload(Instant now, String keyId, SignatureAlgorithm algorithm,
                                    int schemaVersion) {
        return new LicensePayload(
                schemaVersion,
                algorithm.wireName(),
                keyId,
                licenseId,
                activationId,
                customerId,
                customer,
                channel == null ? LicenseChannel.PRODUCTION : channel,
                productCode,
                maxRelease,
                tierLabel,
                now,
                now,
                expiresAt,
                gracePeriodDays,
                machineFingerprints == null ? List.of() : List.copyOf(machineFingerprints),
                nonce,
                features == null ? List.of() : List.copyOf(features),
                limits == null ? Map.of() : Map.copyOf(limits),
                heartbeatRequired,
                heartbeatIntervalDays,
                heartbeatToleranceDays,
                Map.of("issuer", ISSUER));
    }
}
