package dev.accesscore.license.sdk.ffi;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.PointerByReference;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.function.BiFunction;

/**
 * The core, as Java calls it.
 *
 * <p>Everything above this class works in Java types; everything below it is one native
 * boundary. The translation happens here and nowhere else, so a field added to the payload
 * changes one mapper configuration rather than every call site.
 *
 * <p>One instance is enough for a whole application. The core holds no state between calls —
 * every judgement is a function of what it was handed — so the instance is safe to share.
 */
public final class AclicCore {

    /** The shared instance. Loading the library twice would map it twice for nothing. */
    private static final class Holder {
        private static final AclicCore INSTANCE = new AclicCore(NativeLibraryLoader.load());
    }

    private final AclicLibrary library;
    private final ObjectMapper objectMapper;

    /**
     * @param library the loaded core
     */
    public AclicCore(AclicLibrary library) {
        this.library = library;
        this.objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    /**
     * @return the shared core, loading the library on first use
     */
    public static AclicCore shared() {
        return Holder.INSTANCE;
    }

    /**
     * @return the mapper the boundary is crossed with, for a caller that has to read a raw
     *         answer
     */
    public ObjectMapper objectMapper() {
        return objectMapper;
    }

    /**
     * Judges everything a host knows about its license.
     *
     * @param request what the host knows
     * @param responseType the type to read the answer as
     * @param <T> the answer type
     * @return the judgement
     */
    public <T> T evaluate(Object request, Class<T> responseType) {
        return call(library::aclic_evaluate, request, responseType, "evaluate");
    }

    /**
     * Signs a payload into a token.
     *
     * @param request the payload and the signing key
     * @param responseType the type to read the answer as
     * @param <T> the answer type
     * @return the token and the key pair's fingerprint
     */
    public <T> T sign(Object request, Class<T> responseType) {
        return call(library::aclic_sign, request, responseType, "sign");
    }

    /**
     * Checks a token's signature without judging anything else about it.
     *
     * @param request the token and the keys to check it against
     * @param responseType the type to read the answer as
     * @param <T> the answer type
     * @return whether the signature checks out
     */
    public <T> T verifySignature(Object request, Class<T> responseType) {
        return call(library::aclic_verify_signature, request, responseType, "verifySignature");
    }

    /**
     * Reads what this machine reports about itself.
     *
     * @param responseType the type to read the answer as
     * @param <T> the answer type
     * @return the machine's identifiers, hashed
     */
    public <T> T fingerprint(Class<T> responseType) {
        PointerByReference out = new PointerByReference();
        int code = library.aclic_fingerprint(out);
        return read(code, out, responseType, "fingerprint");
    }

    /**
     * Hashes machine identifiers, and matches them against what a license names.
     *
     * <p>Separate from {@link #fingerprint} because reading a machine and calculating over what
     * was read are different things: one is platform input and output, the other is a pure
     * function the conformance vectors can check without a machine to run them on.
     *
     * @param request the operation and its arguments
     * @return the answer
     */
    public JsonNode fingerprintCompute(Object request) {
        return call(library::aclic_fingerprint_compute, request, JsonNode.class,
                "fingerprintCompute");
    }

    /**
     * Writes the activation, heartbeat, or release request a host sends.
     *
     * @param request what the request is built from
     * @param responseType the type to read the answer as
     * @param <T> the answer type
     * @return the prepared request
     */
    public <T> T activationRequest(Object request, Class<T> responseType) {
        return call(library::aclic_activation_request, request, responseType, "activationRequest");
    }

    /**
     * Reads the answer an activation server gave.
     *
     * @param response what the server answered
     * @param responseType the type to read the answer as
     * @param <T> the answer type
     * @return the outcome
     */
    public <T> T activationResponse(Object response, Class<T> responseType) {
        return call(library::aclic_activation_response, response, responseType,
                "activationResponse");
    }

    /**
     * Generates a signing key pair.
     *
     * @param request which algorithm to generate for
     * @param responseType the type to read the answer as
     * @param <T> the answer type
     * @return the key pair
     */
    public <T> T generateKeyPair(Object request, Class<T> responseType) {
        return call(library::aclic_generate_keypair, request, responseType, "generateKeyPair");
    }

    /**
     * Generates and reads customer-facing product keys.
     *
     * @param request the operation and its arguments
     * @return the answer
     */
    public JsonNode productKey(Object request) {
        return call(library::aclic_product_key, request, JsonNode.class, "productKey");
    }

    /**
     * Ranks release versions and checks them against a ceiling.
     *
     * @param request the operation and its arguments
     * @return the answer
     */
    public JsonNode release(Object request) {
        return call(library::aclic_release, request, JsonNode.class, "release");
    }

    /**
     * @return the payload schema number this build reads and writes
     */
    public int schemaVersion() {
        return library.aclic_schema_version();
    }

    /**
     * @return the SDK version the loaded core reports
     */
    public String version() {
        Pointer pointer = library.aclic_version();
        return pointer == null ? "" : pointer.getString(0, StandardCharsets.UTF_8.name());
    }

    /**
     * Calls one boundary function.
     *
     * @param function the native function
     * @param request what to send
     * @param responseType the type to read the answer as
     * @param operation the operation name, for a failure message
     * @param <T> the answer type
     * @return the answer
     */
    private <T> T call(BiFunction<String, PointerByReference, Integer> function, Object request,
                       Class<T> responseType, String operation) {
        String json;
        try {
            json = objectMapper.writeValueAsString(request);
        } catch (IOException e) {
            throw new AclicException(operation, "the request could not be written", e);
        }

        PointerByReference out = new PointerByReference();
        int code = function.apply(json, out);
        return read(code, out, responseType, operation);
    }

    /**
     * Reads an answer and frees the memory the core handed over.
     *
     * @param code what the call returned
     * @param out where the answer was written
     * @param responseType the type to read it as
     * @param operation the operation name, for a failure message
     * @param <T> the answer type
     * @return the answer
     */
    private <T> T read(int code, PointerByReference out, Class<T> responseType, String operation) {
        Pointer pointer = out.getValue();
        String answer = null;
        try {
            if (pointer != null) {
                answer = pointer.getString(0, StandardCharsets.UTF_8.name());
            }
        } finally {
            // Freed whatever the outcome: the core allocated it, and a failure path that
            // skipped the free would leak a little on every refusal.
            if (pointer != null) {
                library.aclic_string_free(pointer);
            }
        }

        if (code != AclicLibrary.ACLIC_OK) {
            throw new AclicException(operation, describe(code, answer), null);
        }
        if (answer == null) {
            throw new AclicException(operation, "the core returned no answer", null);
        }

        try {
            return objectMapper.readValue(answer, responseType);
        } catch (IOException e) {
            throw new AclicException(operation, "the answer could not be read", e);
        }
    }

    /**
     * @param code what the call returned
     * @param answer the error document, when one was written
     * @return a line naming what went wrong
     */
    private String describe(int code, String answer) {
        String reason = switch (code) {
            case AclicLibrary.ACLIC_NULL_ARGUMENT -> "a required argument was null";
            case AclicLibrary.ACLIC_INVALID_UTF8 -> "the request was not valid UTF-8";
            case AclicLibrary.ACLIC_OPERATION_FAILED -> "the operation produced no result";
            case AclicLibrary.ACLIC_PANIC -> "the license core failed";
            default -> "the license core returned " + code;
        };
        if (answer == null || answer.isBlank()) {
            return reason;
        }
        return reason + ": " + answer;
    }

    /** Raised when a call across the boundary did not produce a result. */
    public static class AclicException extends RuntimeException {

        private final String operation;

        /**
         * @param operation which call failed
         * @param message what went wrong
         * @param cause the underlying failure, may be null
         */
        public AclicException(String operation, String message, Throwable cause) {
            super(operation + ": " + message, cause);
            this.operation = operation;
        }

        /**
         * @return which call failed
         */
        public String operation() {
            return operation;
        }
    }
}
