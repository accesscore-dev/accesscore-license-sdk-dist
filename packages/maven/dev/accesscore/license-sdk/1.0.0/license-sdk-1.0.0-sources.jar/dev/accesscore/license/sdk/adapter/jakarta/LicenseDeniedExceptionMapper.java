package dev.accesscore.license.sdk.adapter.jakarta;

import dev.accesscore.license.sdk.adapter.DenialBody;
import dev.accesscore.license.sdk.gate.LicenseDeniedException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

/**
 * Turns a gate refusal into a Jakarta REST response.
 *
 * <p>Registered as a provider, it covers every resource at once: a refusal thrown anywhere in a
 * Jakarta application answers with the same status and the same document a Spring one does.
 */
@Provider
public class LicenseDeniedExceptionMapper implements ExceptionMapper<LicenseDeniedException> {

    @Override
    public Response toResponse(LicenseDeniedException denied) {
        return Response.status(denied.httpStatus())
                .type(MediaType.APPLICATION_JSON_TYPE)
                .entity(DenialBody.of(denied).asMap())
                .build();
    }
}
