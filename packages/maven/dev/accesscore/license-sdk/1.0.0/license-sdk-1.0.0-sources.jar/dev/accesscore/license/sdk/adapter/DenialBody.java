package dev.accesscore.license.sdk.adapter;

import dev.accesscore.license.sdk.gate.LicenseDeniedException;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The body every adapter writes.
 *
 * <p>One shape, so the contract tests can assert the same document whichever framework produced
 * it. The message key travels untranslated: the host owns its locales, and an adapter that
 * translated would need one phrase book per framework.
 *
 * @param errorCode the code a client branches on; always begins with {@code LICENSE_}
 * @param status the status the judgement concluded
 * @param messageKey the key the host resolves against the request locale
 * @param arguments the values that fill the message's placeholders
 */
public record DenialBody(String errorCode, String status, String messageKey,
                         List<Object> arguments) {

    /**
     * @param denied what the gate refused
     * @return the document that refusal is written as
     */
    public static DenialBody of(LicenseDeniedException denied) {
        return new DenialBody(
                denied.errorCode(),
                denied.status() == null ? null : denied.status().name(),
                denied.denial().messageKey(),
                denied.denial().arguments() == null ? List.of() : denied.denial().arguments());
    }

    /**
     * @return the document as a map, for a framework that serializes one rather than a record
     */
    public Map<String, Object> asMap() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("errorCode", errorCode);
        map.put("status", status);
        map.put("messageKey", messageKey);
        map.put("arguments", arguments);
        return map;
    }
}
