package dev.accesscore.license.sdk.model;

/**
 * What one judgement concluded.
 *
 * <p>Three states keep a deployment operating. {@link #RELEASE_NOT_ENTITLED} is one of them on
 * purpose: a release above the ceiling that closed the state gate would stop access control at
 * the door. In that state the available-feature list is empty, so only the paid modules close.
 *
 * <p>The names are the core's, so a status a log names here reads the same in a log written by
 * a deployment in another language.
 */
public enum LicenseStatus {

    /** Every check passed. */
    VALID,

    /** Expired, but inside the grace period. */
    GRACE_PERIOD,

    /** The running release is above what the contract entitles. */
    RELEASE_NOT_ENTITLED,

    /** Expired past the grace period. */
    EXPIRED,

    /**
     * The signature does not match, the algorithm is not allowed, or a production-channel token
     * carries a wildcard fingerprint.
     */
    INVALID_SIGNATURE,

    /** The fingerprints stamped into the token do not describe this machine. */
    MACHINE_MISMATCH,

    /** Not one machine identifier could be read, so the binding cannot be checked at all. */
    FINGERPRINT_UNAVAILABLE,

    /** No license is registered here. */
    NOT_ACTIVATED,

    /** A token is present but cannot be read. */
    NOT_LOADED,

    /** The token is written in a schema this deployment does not read. */
    SCHEMA_UNSUPPORTED,

    /** The issuing server revoked this activation. */
    REVOKED,

    /** The clock moved back past the recorded watermark. */
    CLOCK_TAMPERED,

    /** The binary does not hash to what the host expected. */
    INTEGRITY_FAILED,

    /** A required heartbeat did not succeed inside its tolerance. */
    HEARTBEAT_OVERDUE,

    /** The license belongs to a different product. */
    PRODUCT_MISMATCH;

    /**
     * @return whether the deployment keeps operating under this status
     */
    public boolean isUsable() {
        return this == VALID || this == GRACE_PERIOD || this == RELEASE_NOT_ENTITLED;
    }

    /**
     * @return the code a client reads to tell a license denial from a permission denial
     */
    public String errorCode() {
        return "LICENSE_" + name();
    }
}
